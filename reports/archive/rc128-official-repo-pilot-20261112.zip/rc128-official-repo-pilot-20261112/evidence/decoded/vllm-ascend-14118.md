### Your current environment

<details>
<summary>The output of `python collect_env.py`</summary>

```text
Collecting environment information...
PyTorch version: 2.9.0+cpu
Is debug build: False

OS: Ubuntu 22.04.5 LTS (aarch64)
GCC version: (Ubuntu 11.4.0-1ubuntu1~22.04.3) 11.4.0
Clang version: 15.0.7
CMake version: version 4.3.2
Libc version: glibc-2.35

Python version: 3.11.14 (main, Feb 26 2026, 04:49:14) [GCC 11.4.0] (64-bit runtime)
Python platform: Linux-4.19.90-2102.2.0.0068.3.ctl2.aarch64-aarch64-with-glibc2.35

CPU:
Architecture:                    aarch64
CPU op-mode(s):                  64-bit
Byte Order:                      Little Endian
CPU(s):                          192
On-line CPU(s) list:             0-191
Vendor ID:                       HiSilicon
BIOS Vendor ID:                  HiSilicon
Model name:                      Kunpeng-920
BIOS Model name:                 HUAWEI Kunpeng 920 5250
Model:                           0
Thread(s) per core:              1
Core(s) per socket:              48
Socket(s):                       4
Stepping:                        0x1
BogoMIPS:                        200.00
Flags:                           fp asimd evtstrm aes pmull sha1 sha2 crc32 atomics fphp asimdhp cpuid asimdrdm jscvt fcma dcpop asimddp asimdfhm ssbs
L1d cache:                       12 MiB (192 instances)
L1i cache:                       12 MiB (192 instances)
L2 cache:                        96 MiB (192 instances)
L3 cache:                        192 MiB (8 instances)
NUMA node(s):                    4
NUMA node0 CPU(s):               0-47
NUMA node1 CPU(s):               48-95
NUMA node2 CPU(s):               96-143
NUMA node3 CPU(s):               144-191
Vulnerability Itlb multihit:     Not affected
Vulnerability L1tf:              Not affected
Vulnerability Mds:               Not affected
Vulnerability Meltdown:          Not affected
Vulnerability Spec store bypass: Mitigation; Speculative Store Bypass disabled via prctl
Vulnerability Spectre v1:        Mitigation; __user pointer sanitization
Vulnerability Spectre v2:        Not affected
Vulnerability Srbds:             Not affected
Vulnerability Tsx async abort:   Not affected

Versions of relevant libraries:
[pip3] numpy==1.26.4
[pip3] pyzmq==27.1.0
[pip3] torch==2.9.0+cpu
[pip3] torch_npu==2.9.0.post1+gitee7ba04
[pip3] torchaudio==2.9.0
[pip3] torchvision==0.24.0
[pip3] transformers==4.57.6
[pip3] triton-ascend==3.2.0.dev20260322
[conda] Could not collect
vLLM Version: 0.18.0
vLLM Ascend Version: 0.1.dev2924+ge5f7e2f43 (git sha: e5f7e2f43)

ENV Variables:
ASCEND_TOOLKIT_LATEST_HOME=/usr/local/Ascend/ascend-toolkit/latest
ATB_OPSRUNNER_KERNEL_CACHE_LOCAL_COUNT=1
ATB_STREAM_SYNC_EVERY_RUNNER_ENABLE=0
ATB_STREAM_SYNC_EVERY_KERNEL_ENABLE=0
ATB_OPSRUNNER_KERNEL_CACHE_GLOABL_COUNT=5
ATB_HOME_PATH=/usr/local/Ascend/nnal/atb/latest/atb/cxx_abi_1
ASCEND_TOOLKIT_HOME=/usr/local/Ascend/cann-8.5.1
ATB_COMPARE_TILING_EVERY_KERNEL=0
ASCEND_OPP_PATH=/usr/local/Ascend/cann-8.5.1/opp
LD_LIBRARY_PATH=/usr/local/Ascend/nnal/atb/latest/atb/cxx_abi_1/lib:/usr/local/Ascend/nnal/atb/latest/atb/cxx_abi_1/examples:/usr/local/Ascend/nnal/atb/latest/atb/cxx_abi_1/tests/atbopstest:/usr/local/Ascend/ascend-toolkit/latest/tools/aml/lib64:/usr/local/Ascend/ascend-toolkit/latest/tools/aml/lib64/plugin:/usr/local/Ascend/ascend-toolkit/latest/lib64:/usr/local/Ascend/ascend-toolkit/latest/lib64/plugin/opskernel:/usr/local/Ascend/ascend-toolkit/latest/lib64/plugin/nnengine:/usr/local/Ascend/ascend-toolkit/latest/opp/built-in/op_impl/ai_core/tbe/op_tiling:/usr/local/Ascend/cann-8.5.1/tools/aml/lib64:/usr/local/Ascend/cann-8.5.1/tools/aml/lib64/plugin:/usr/local/Ascend/cann-8.5.1/lib64:/usr/local/Ascend/cann-8.5.1/lib64/plugin/opskernel:/usr/local/Ascend/cann-8.5.1/lib64/plugin/nnengine:/usr/local/Ascend/cann-8.5.1/opp/built-in/op_impl/ai_core/tbe/op_tiling:/usr/local/Ascend/driver/lib64:/usr/local/Ascend/driver/lib64/common/:/usr/local/Ascend/driver/lib64/driver/:/usr/local/python3.11.14/lib::/usr/local/lib
ASCEND_AICPU_PATH=/usr/local/Ascend/cann-8.5.1
ATB_STREAM_SYNC_EVERY_OPERATION_ENABLE=0
ASCEND_HOME_PATH=/usr/local/Ascend/cann-8.5.1
ATB_MATMUL_SHUFFLE_K_ENABLE=1
ATB_WORKSPACE_MEM_ALLOC_ALG_TYPE=1
ATB_SHARE_MEMORY_NAME_SUFFIX=
TORCH_DEVICE_BACKEND_AUTOLOAD=1
PYTORCH_NVML_BASED_CUDA_CHECK=1
TORCHINDUCTOR_COMPILE_THREADS=1


NPU:
+------------------------------------------------------------------------------------------------+
| npu-smi 25.2.3                   Version: 25.2.3                                               |
+---------------------------+---------------+----------------------------------------------------+
| NPU   Name                | Health        | Power(W)    Temp(C)           Hugepages-Usage(page)|
| Chip                      | Bus-Id        | AICore(%)   Memory-Usage(MB)  HBM-Usage(MB)        |
+===========================+===============+====================================================+
| 0     910B3               | OK            | 99.6        36                0    / 0             |
| 0                         | 0000:C1:00.0  | 0           0    / 0          59559/ 65536         |
+===========================+===============+====================================================+
| 1     910B3               | OK            | 89.3        34                0    / 0             |
| 0                         | 0000:C2:00.0  | 0           0    / 0          59552/ 65536         |
+===========================+===============+====================================================+
| 2     910B3               | OK            | 94.3        36                0    / 0             |
| 0                         | 0000:81:00.0  | 0           0    / 0          59552/ 65536         |
+===========================+===============+====================================================+
| 3     910B3               | OK            | 93.1        35                0    / 0             |
| 0                         | 0000:82:00.0  | 0           0    / 0          59552/ 65536         |
+===========================+===============+====================================================+
| 4     910B3               | OK            | 96.2        41                0    / 0             |
| 0                         | 0000:01:00.0  | 0           0    / 0          59552/ 65536         |
+===========================+===============+====================================================+
| 5     910B3               | OK            | 91.0        39                0    / 0             |
| 0                         | 0000:02:00.0  | 0           0    / 0          59556/ 65536         |
+===========================+===============+====================================================+
| 6     910B3               | OK            | 95.1        40                0    / 0             |
| 0                         | 0000:41:00.0  | 0           0    / 0          59551/ 65536         |
+===========================+===============+====================================================+
| 7     910B3               | OK            | 97.0        40                0    / 0             |
| 0                         | 0000:42:00.0  | 0           0    / 0          59552/ 65536         |
+===========================+===============+====================================================+
+---------------------------+---------------+----------------------------------------------------+
| NPU     Chip              | Process id    | Process name             | Process memory(MB)      |
+===========================+===============+====================================================+
| 0       0                 | 26251         |                          | 56183                   |
+===========================+===============+====================================================+
| 1       0                 | 27044         |                          | 56183                   |
+===========================+===============+====================================================+
| 2       0                 | 27879         |                          | 56183                   |
+===========================+===============+====================================================+
| 3       0                 | 28540         |                          | 56183                   |
+===========================+===============+====================================================+
| 4       0                 | 29346         |                          | 56183                   |
+===========================+===============+====================================================+
| 5       0                 | 30180         |                          | 56187                   |
+===========================+===============+====================================================+
| 6       0                 | 30863         |                          | 56183                   |
+===========================+===============+====================================================+
| 7       0                 | 31552         |                          | 56183                   |
+===========================+===============+====================================================+

CANN:
package_name=Ascend-cann-toolkit
version=8.5.1
innerversion=V100R001C25SPC002B220
compatible_version=[V100R001C15],[V100R001C18],[V100R001C19],[V100R001C20],[V100R001C21],[V100R001C23]
arch=aarch64
os=linux
path=/usr/local/Ascend/cann-8.5.1
```

</details>


### 🐛 Describe the bug

1、test design：
PRIME_PROMPT = "Xiao Wang's full name is Wang Xiaoxiao, and Xiao Zhang's full name is Zhang Jiansen."
PROBE_PROMPT = "What is Xiao Zhang's full name?"
LEAK_MARKERS = ("Wang Xiaoxiao", "Zhang Jiansen")

(1) Two-stage workflow:
- Prime Stage: Launch 100 concurrent requests. Each request is constructed as [3008-token prefix of repeated "a"] + padded PRIME_PROMPT, to fill KV cache with marker texts.

- Probe Stage: Launch 100 concurrent requests with the identical common prefix, followed only by PROBE_PROMPT (no embedded answer).

(2) Judgment rules:
- Response contains Wang Xiaoxiao / Zhang Jiansen: cross-context leak (cache corruption reproduced)
- Response returns "unknown / not provided": normal result
- Other outputs: ambiguous

2、test script：
```
#!/usr/bin/env python3
"""One-command reproducer for concurrent vLLM prefix-cache context leakage."""
from __future__ import annotations

import argparse
import json
import os
import ssl
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen


PROFILES = {
    "confirmed": {
        "count_per_phase": 100,
        "concurrency": 100,
        "prompt_repeat": 5000,
        "common_prefix_target_tokens": 3000,
    },
    "quick": {
        "count_per_phase": 32,
        "concurrency": 32,
        "prompt_repeat": 512,
        "common_prefix_target_tokens": 1024,
    },
}

DEFAULT_BASE_URL = "http://127.0.0.1:8000/v1"


def env(*names: str) -> str:
    for name in names:
        value = os.getenv(name)
        if value and value.strip():
            return value.strip()
    return ""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--base-url",
        default=env("OPENAI_BASE_URL", "VLLM_BASE_URL") or DEFAULT_BASE_URL,
        help=f"OpenAI-compatible vLLM base URL (default: {DEFAULT_BASE_URL})",
    )
    parser.add_argument("--api-key", default=env("OPENAI_API_KEY", "VLLM_API_KEY"))
    parser.add_argument(
        "--model",
        default=env("OPENAI_MODEL", "VLLM_MODEL"),
        help="Model name; automatically discovered from /models when omitted",
    )
    parser.add_argument(
        "--profile",
        choices=sorted(PROFILES),
        default="confirmed",
        help="confirmed matches the environment that reproduced 69/100 leaks; quick is screening only",
    )
    parser.add_argument("--count-per-phase", type=int)
    parser.add_argument("--concurrency", type=int)
    parser.add_argument("--prompt-repeat", type=int)
    parser.add_argument("--common-prefix-target-tokens", type=int)
    parser.add_argument("--phase-gap-seconds", type=float, default=0.0)
    parser.add_argument("--timeout", type=float, default=300.0)
    parser.add_argument("--prime-max-tokens", type=int, default=128)
    parser.add_argument("--probe-max-tokens", type=int, default=512)
    parser.add_argument("--no-stream", action="store_true")
    parser.add_argument("--header", action="append", default=[])
    parser.add_argument("--extra-body", default="{}")
    parser.add_argument("--insecure", action="store_true")
    parser.add_argument("--preflight-timeout", type=float, default=10.0)
    parser.add_argument(
        "--with-control",
        action="store_true",
        help="Also run the unique-leading-character control experiment",
    )
    parser.add_argument("--output-dir", default="")
    return parser


def models_url(base_url: str) -> str:
    candidate = base_url.strip()
    if not candidate:
        raise ValueError("base URL is required")
    if "://" not in candidate:
        candidate = f"http://{candidate}"
    parsed = urlsplit(candidate)
    if not parsed.netloc:
        raise ValueError(f"invalid base URL: {base_url}")
    path = parsed.path.rstrip("/")
    if path.endswith("/chat/completions"):
        path = path[: -len("/chat/completions")]
    if not path.endswith("/v1"):
        path = f"{path}/v1" if path else "/v1"
    return urlunsplit((parsed.scheme, parsed.netloc, f"{path}/models", parsed.query, ""))


def request_headers(args: argparse.Namespace) -> dict[str, str]:
    headers = {"Accept": "application/json"}
    for value in args.header:
        name, separator, header_value = value.partition(":")
        if not separator or not name.strip():
            raise ValueError(f"invalid header, expected 'Name: value': {value}")
        headers[name.strip()] = header_value.strip()
    if args.api_key and not any(name.lower() == "authorization" for name in headers):
        headers["Authorization"] = f"Bearer {args.api_key}"
    return headers


def discover_models(args: argparse.Namespace) -> list[str]:
    url = models_url(args.base_url)
    context = ssl._create_unverified_context() if args.insecure else None
    request = Request(url, headers=request_headers(args), method="GET")
    try:
        with urlopen(request, timeout=args.preflight_timeout, context=context) as response:
            payload = json.loads(response.read().decode("utf-8", errors="replace"))
    except HTTPError as exc:
        body = exc.read(1000).decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"GET {url} returned HTTP {exc.code}: {body or exc.reason}") from exc
    except URLError as exc:
        raise RuntimeError(f"cannot connect to {url}: {exc.reason}") from exc
    except (TimeoutError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"invalid response from {url}: {exc}") from exc
    items = payload.get("data") if isinstance(payload, dict) else None
    models = [
        str(item.get("id") or "").strip()
        for item in items or []
        if isinstance(item, dict) and str(item.get("id") or "").strip()
    ]
    if not models:
        raise RuntimeError(f"GET {url} returned no model IDs")
    return models


def resolve_settings(args: argparse.Namespace) -> dict[str, int]:
    profile = dict(PROFILES[args.profile])
    for name in profile:
        override = getattr(args, name)
        if override is not None:
            profile[name] = override
    if profile["count_per_phase"] <= 0:
        raise ValueError("count per phase must be positive")
    if not 1 <= profile["concurrency"] <= profile["count_per_phase"]:
        raise ValueError("concurrency must be between 1 and count per phase")
    if profile["prompt_repeat"] <= 0 or profile["common_prefix_target_tokens"] <= 0:
        raise ValueError("prompt repeat and common prefix size must be positive")
    return profile


def build_probe_command(
    args: argparse.Namespace,
    settings: dict[str, int],
    *,
    output: Path,
    isolated: bool,
) -> list[str]:
    probe = Path(__file__).with_name("probe_llm_sequential_context_leak.py")
    command = [
        sys.executable,
        str(probe),
        "--base-url",
        args.base_url,
        "--model",
        args.model,
        "--count-per-phase",
        str(settings["count_per_phase"]),
        "--concurrency",
        str(settings["concurrency"]),
        "--prompt-repeat",
        str(settings["prompt_repeat"]),
        "--common-prefix-target-tokens",
        str(settings["common_prefix_target_tokens"]),
        "--phase-gap-seconds",
        str(args.phase_gap_seconds),
        "--timeout",
        str(args.timeout),
        "--prime-max-tokens",
        str(args.prime_max_tokens),
        "--probe-max-tokens",
        str(args.probe_max_tokens),
        "--extra-body",
        args.extra_body,
        "--output",
        str(output),
    ]
    for header in args.header:
        command.extend(["--header", header])
    if args.no_stream:
        command.append("--no-stream")
    if args.insecure:
        command.append("--insecure")
    if isolated:
        command.append("--unique-probe-leading-char")
    return command


def load_report(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"cannot read experiment report {path}: {exc}") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("summary"), dict):
        raise RuntimeError(f"invalid experiment report: {path}")
    return payload


def summarize_report(report: dict[str, Any]) -> dict[str, Any]:
    summary = report["summary"]
    prime = summary.get("prime") or {}
    probe = summary.get("probe") or {}
    return {
        "runId": report.get("runId", ""),
        "crossContextLeaks": int(summary.get("crossContextLeaks", 0) or 0),
        "failures": int(prime.get("failures", 0) or 0) + int(probe.get("failures", 0) or 0),
        "successes": int(prime.get("successes", 0) or 0) + int(probe.get("successes", 0) or 0),
        "elapsedSeconds": round(
            float(prime.get("elapsedSeconds", 0) or 0)
            + float(probe.get("elapsedSeconds", 0) or 0),
            6,
        ),
        "probeLatencySeconds": probe.get("latencySeconds") or {},
        "probeClassifications": summary.get("probeClassifications") or {},
    }


def classify_verdict(
    shared: dict[str, Any],
    isolated: dict[str, Any] | None = None,
) -> tuple[str, str]:
    if shared["failures"] or (isolated is not None and isolated["failures"]):
        return "INCONCLUSIVE_REQUEST_FAILURES", "请求失败，不能判断是否存在 KV Cache 串扰"
    if isolated is None:
        if shared["crossContextLeaks"] > 0:
            return "LEAK_DETECTED", "共享前缀实验观察到跨上下文内容"
        return "NOT_REPRODUCED", "本次运行未观察到跨上下文内容"
    if shared["crossContextLeaks"] > 0 and isolated["crossContextLeaks"] == 0:
        return "REPRODUCED", "共享前缀发生串扰，唯一首字符对照组未发生串扰"
    if shared["crossContextLeaks"] > 0:
        return "LEAK_PRESENT_ISOLATION_INCONCLUSIVE", "两组均发生串扰，问题存在但无法归因于共享前缀"
    if isolated["crossContextLeaks"] > 0:
        return "ISOLATED_GROUP_LEAKED", "仅唯一首字符对照组发生串扰，结果异常且需要复查"
    return "NOT_REPRODUCED", "本次运行未观察到跨上下文内容"


def default_output_dir() -> Path:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return Path(__file__).resolve().parents[1] / "TOC_TEST" / f"vllm-prefix-cache-repro-{timestamp}"


def run_probe(command: list[str], label: str, *, environment: dict[str, str]) -> int:
    print(f"\n{'=' * 72}\n{label}\n{'=' * 72}", flush=True)
    completed = subprocess.run(command, check=False, env=environment)
    return int(completed.returncode)


def main() -> int:
    args = build_parser().parse_args()
    try:
        settings = resolve_settings(args)
        extra_body = json.loads(args.extra_body)
        if args.preflight_timeout <= 0:
            raise ValueError("preflight timeout must be positive")
        available_models = discover_models(args)
    except (ValueError, RuntimeError, json.JSONDecodeError) as exc:
        raise SystemExit(f"Configuration error: {exc}") from exc
    if not isinstance(extra_body, dict):
        raise SystemExit("Configuration error: --extra-body must be a JSON object")
    if not args.model:
        args.model = available_models[0]
        print(f"Auto-discovered model: {args.model}")
    elif args.model not in available_models:
        print(
            f"WARNING: requested model {args.model!r} is not listed by /models; "
            f"available={available_models!r}",
            file=sys.stderr,
        )

    output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else default_output_dir()
    output_dir.mkdir(parents=True, exist_ok=False)
    shared_path = output_dir / "01-shared-prefix.json"
    isolated_path = output_dir / "02-unique-leading-character.json" if args.with_control else None

    print("vLLM concurrent prefix-cache leakage reproducer")
    print(f"Endpoint: {args.base_url}")
    print(f"Model: {args.model}")
    print(f"Preflight: OK ({len(available_models)} model(s) reported)")
    print(f"Profile: {args.profile} {json.dumps(settings, sort_keys=True)}")
    print(f"Output: {output_dir}")
    if args.profile == "confirmed":
        request_count = settings["count_per_phase"] * 2 * (2 if args.with_control else 1)
        print(
            "WARNING: confirmed profile sends approximately "
            f"{request_count} requests with very large prompts."
        )

    child_environment = os.environ.copy()
    if args.api_key:
        child_environment["OPENAI_API_KEY"] = args.api_key

    shared_status = run_probe(
        build_probe_command(args, settings, output=shared_path, isolated=False),
        (
            "Experiment 1/2: shared prefix (expected to expose the bug)"
            if args.with_control
            else "Experiment: shared prefix context leak"
        ),
        environment=child_environment,
    )
    isolated_status: int | None = None
    if isolated_path is not None:
        isolated_status = run_probe(
            build_probe_command(args, settings, output=isolated_path, isolated=True),
            "Experiment 2/2: unique first character (control group)",
            environment=child_environment,
        )

    try:
        shared = summarize_report(load_report(shared_path))
        isolated = summarize_report(load_report(isolated_path)) if isolated_path is not None else None
        verdict, description = classify_verdict(shared, isolated)
    except RuntimeError as exc:
        verdict = "INCONCLUSIVE_MISSING_REPORT"
        description = str(exc)
        shared = {"processExitCode": shared_status}
        isolated = {"processExitCode": isolated_status} if isolated_path is not None else None

    combined = {
        "schemaVersion": 1,
        "completedAt": datetime.now(timezone.utc).isoformat(),
        "endpoint": args.base_url,
        "model": args.model,
        "profile": args.profile,
        "settings": settings,
        "controlExperimentEnabled": args.with_control,
        "verdict": verdict,
        "description": description,
        "sharedPrefix": {**shared, "processExitCode": shared_status, "report": str(shared_path)},
        "uniqueLeadingCharacter": (
            {
                **(isolated or {}),
                "processExitCode": isolated_status,
                "report": str(isolated_path),
            }
            if isolated_path is not None
            else None
        ),
    }
    summary_path = output_dir / "SUMMARY.json"
    summary_path.write_text(json.dumps(combined, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"\n{'=' * 72}")
    print(f"VERDICT: {verdict}")
    print(description)
    result_line = f"Shared prefix leaks: {shared.get('crossContextLeaks', 'unknown')}"
    if isolated is not None:
        result_line += (
            "; unique-leading-character leaks: "
            f"{isolated.get('crossContextLeaks', 'unknown')}"
        )
    print(result_line)
    print(f"Summary: {summary_path}")
    print(f"{'=' * 72}")
    return 0 if verdict in {"REPRODUCED", "LEAK_DETECTED"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
```

3、test result：
(1) python3 reproduce_vllm_prefix_cache_leak.py --base-url http://10.1.36.56:8000/v1 --model dsv4 --profile quick --with-control ======================================================================== VERDICT: NOT_REPRODUCED 本次运行未观察到跨上下文内容 Shared prefix leaks: 0; unique-leading-character leaks: 0 Summary: /TOC_TEST/vllm-prefix-cache-repro-20260812T065709Z/SUMMARY.json ======================================================================== 
(2) python3 reproduce_vllm_prefix_cache_leak.py --base-url http://10.1.36.56:8000/v1 --model dsv4 --with-control ======================================================================== VERDICT: REPRODUCED 共享前缀发生串扰，唯一首字符对照组未发生串扰 Shared prefix leaks: 85; unique-leading-character leaks: 0 Summary: /TOC_TEST/vllm-prefix-cache-repro-20260812T063716Z/SUMMARY.json ======================================================================== 
(3) python3 reproduce_vllm_prefix_cache_leak.py --base-url http://10.1.36.56:8000/v1 --model dsv4 ======================================================================== VERDICT: LEAK_DETECTED 共享前缀实验观察到跨上下文内容 Shared prefix leaks: 84 Summary: /TOC_TEST/vllm-prefix-cache-repro-20260812T062903Z/SUMMARY.json ========================================================================