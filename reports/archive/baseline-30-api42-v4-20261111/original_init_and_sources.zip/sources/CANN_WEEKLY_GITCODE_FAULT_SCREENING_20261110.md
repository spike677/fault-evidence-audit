精度工厂周报 · 算子故障筛选与 GitCode 技术分析（Agent 2 独立交付 · 精简版）

• 执行日期：2026-11-10　｜　角色：Agent 2（与 Agent 1 的 30 条模式基线并行、独立）
• 用途：供 Codex 执行 CANN 模式库 Init / Expansion，不是完整周报归档
• 范围约束：不读取、不重做原始 30 条 CANN 模式库；不做 COVERED/EXTEND/NEW 正式判定；不自动新增/合并/删除模式
• 交付结构：8 个 Part（见下）

Part 1　执行摘要

1.1 数据范围与统计口径（修正版）

数据范围	数量	含义
原始周报记录	267	9 个故障 Sheet 的原始筛选输入
去重记录	248	按描述归一化（19 组跨 Sheet 重复）
粗筛	116	问题来源/描述/根因任一含算子、通信、框架算子词
严筛	114	在 116 上按「根因/进展/过程记录」严格判定通过（剔除 2 条非算子根因）
补库候选	138	P0 优先集 77 + P1 新增 61（P0 是 138 的子集，非漏斗下游）
P0 优先集	77	138 中的高优先级子集，去重后约 69 个独立事件
GitCode PR（去重）	27	本轮取得完整 Diff的 PR 数量（不是故障数）
关联周报故障记录	30	引用这 27 个 PR（及 1 commit）的周报记录数
GitCode 目标	31	27 PR + 3 Issue + 1 Commit

口径修正：① 138 与 77 是包含关系，不是「77 再筛出 138」；② 粗筛 116 / 严筛 114 的规则如上表一句话；③ 27 = 去重 PR 数，与被引用的周报故障记录数（30）分开统计；④ 31 个目标是 27 PR + 3 Issue + 1 Commit，不能把 3 Issue + 1 Commit 当成 4 个「未取得 Diff 的 PR」。

1.2 GitCode 采集结果（本轮新增）

项目	结果
27 个 PR 完整 Diff	27 / 27 全部取得（此前 29 份 GitCode 快照均为 PARTIAL、无 Diff）
3 个 Issue	保留关联与页面正文（Issue 本无 Diff）
1 个 Commit	页面正文未渲染 → DIFF_UNAVAILABLE，保留关联（WB-034）
采集方式	用户已登录 Edge，CDP 127.0.0.1:9222，只读；不导出 Cookie/Token
落盘	work/gitcode_diff/*.json（31）；Diff 原文 work/handoff_tables/pr_diff_bodies.txt

1.3 结论

1. 27 个 PR 的代码级修复证据已完整取得，是本文件最有价值的部分（Part 3）。
2. 失效机理集中在 Part 5 的 G1–G11 十一组；G1–G11 是 Codex 判断「哪些案例归入同一模式」的核心材料。
3. 77 条索引（Part 2）负责防止漏掉其他故障；其中 30 条有 GitCode（重点），47 条无 GitCode（简要索引）。
4. 未解决与证据缺口见 Part 6，保留 UNKNOWN / 冲突 / 无 Diff / 证据不足项。

Part 2　周报故障索引（77 条优先集）

2.1 有 GitCode 关联的故障记录（30 条，重点关注）

WB	描述	算子	周报根因	GitCode
WB-001	【京东】qwen3-1.7B模型推理结果mindie与torch_npu差异较多	rms_norm / ROPE		https://gitcode.com/cann/ascend-transformer-boost/pull/2094
WB-002	【移动九天】推理图差异	baddbmm		https://gitcode.com/cann/ops-nn/pull/10622
WB-009	【云道】【四野】同代码开确定性，拉两次任务，loss有差异	rmsnorm / matmul	8.1.RC1上FA算子内部竞争导致，数据搬迁操作前后未添加同步机制导致结果出现差异	https://gitcode.com/cann/ops-transformer/pull/12716; https://gitcode.com/cann/ops-transfor
WB-010	【ZJ】M12模型训练单机gnorm spike	rmsnorm	aclnn框架rmsnorm处host-tiling-cache逻辑错误引入,同一算子非连续输入和连	https://gitcode.com/cann/ascend-transformer-boost/pull/2094
WB-023	【客户】：电信 【版本】：MindIE	Embedding / hccl		https://gitcode.com/cann/hccl/pull/1034
WB-025	【联通】【vLLM】Qwen3-Embedding	torch_npu.npu_fusion_att	Pooling Model的Attention计算调用了无法使用KV Cache的torch_npu	https://gitcode.com/cann/ops-transformer/pull/8448; https://gitcode.com/cann/ops-transform
WB-027	【推理开发部】GLM5	TOPK / topk	逐层比对的余弦相似度差异根因，以及对精度的影响     1. TOPK专家选择结果，GPU和NPU有	https://gitcode.com/cann/ops-math/pull/4871
WB-028	【腾讯】【vllm】【A5】HY-V3		CANN B087版本，使用的token_unpermute算子不支持含小于0元素的sorted_i	https://gitcode.com/Ascend/op-plugin/pull/4833
WB-029	【推理开发部】【vllm】【A3】DeepSeek-V4-Pro	compressor	compressor算子内存读写越界，导致KV中出现NaN	https://gitcode.com/cann/ops-transformer/pull/8367; https://gitcode.com/cann/ops-transform
WB-032	【腾讯】【龙虾】【vllm】【A5】GLM 5	quant_sparse_flash_atten	quant_sparse_flash_attention算子只支持FP8的KV Cache，不支持m	https://gitcode.com/cann/ops-nn/pull/7443
WB-033	【腾讯】【vllm】【A5】HY-V3	all_reduce	CANN 9.1.0的all_reduce算子存在精度问题	https://gitcode.com/cann/hccl/pull/1034
WB-034	【腾讯】【vllm】【A5】HY-V3		FP8 Atten算子对静态量化的V scale读取有问题	https://gitcode.com/cann/ops-transformer/commit/0a9e975f6900c68cf3f497b5dc489176a2272896?r
WB-036	【腾讯】HY-V3 W8A8量化回答乱码	npu_dequant_swiglu_quant	在输出维度未对齐64字节时npu_dequant_swiglu_quant算子存在精度问题	https://gitcode.com/cann/ops-transformer/pull/8766; https://gitcode.com/cann/ops-transform
WB-038	【腾讯】HYImage3.5 调频算子接入后内存报错	frequency_regulator	mindie-sd接入算子 aclnn两阶段封装过程内存分配存在问题	https://gitcode.com/Ascend/MindIE-SD/pull/548/diffs
WB-042	【MY】Deepseekv3.2 GRPO训练loss nan	npu_grouped_matmul	npu_grouped_matmul问题，输出nan	https://gitcode.com/cann/ops-transformer/pull/2077
WB-044	【训练开发部】模型训练反向出现nan	Lightning Indexer	Lightning Indexer算子输出随机初始化用的empty，会有一些空行未作逻辑处理，导致直	https://gitcode.com/cann/ops-transformer/pull/2077
WB-046	【联通】【vLLM】Qwen3-Embedding	torch_npu.npu_fused_infe	当前代码逻辑（vllm-ascend 0.13-0.17），pooling model的Attent	https://gitcode.com/cann/ops-transformer/pull/8448; https://gitcode.com/cann/ops-transform
WB-047	【ZJ】M12模型训练单机gnorm spike	rmsnorm	aclnn框架rmsnorm处host-tiling-cache逻辑错误引入,同一算子非连续输入和连	https://gitcode.com/cann/ascend-transformer-boost/pull/2094
WB-049	【ZJ】智创seedance2.0 512卡训练首step出现loss nan	seg_reduce / matmul	1、融合算子seg_reduce在处理空tensor（0*4的shape）时，没有处理输出tenso	https://gitcode.com/cann/ops-transformer/pull/2077
WB-056	【ZJ】m8 gnorm spike	matmul	正常现象，针对这类shape, matmulv2切到了matmut v3, 产生计算差异	https://gitcode.com/cann/ops-nn/pull/2285
WB-057	【美团】切1230版本 反向nan	rmsnorm	aclnn框架rmsnorm处host-tiling-cache逻辑错误引入,同一算子非连续输入和连	https://gitcode.com/cann/ascend-transformer-boost/pull/2094
WB-064	【腾讯】HY-V3	all_reduce	CANN 9.1.0的all_reduce算子存在精度问题（日构建版本的问题）	https://gitcode.com/cann/hccl/pull/1034
WB-065	【字节】sd2.0 pro loss nan	softmax	FA反向算子：单算子用例分析：检测qkv发现qkv输入的值域较大，导致q@k的结果产生大几百的正浮点	https://gitcode.com/cann/ops-transformer/pull/3901; https://gitcode.com/cann/ops-transform
WB-070	【蚂蚁】DS v3.2 speciale verl推理结果异常	sfa	sfa算子核间同步问题	https://gitcode.com/cann/ops-transformer/pull/8445; https://gitcode.com/cann/ops-transform
WB-071	【蚂蚁】Ling-V2.5 vllm适配推理乱码	mla	1.ring_mla和小算子输出存在差距，客户提供的实现未使用mask，vllm-ascend实现传	https://gitcode.com/cann/ascend-transformer-boost/pull/2207
WB-072	【智谱】qwen-image-edit模型NPU训练效果不达标	repeat_interleave / rmsn	两边首步gnorm不一致的原因是npu上使用的repeat_interleave算子反向使用fp32	https://gitcode.com/cann/ops-nn/pull/6170
WB-073	mindspeed-llm dsv4训练确定性固定不住		lightning_indexer算子存在内存踩踏	https://gitcode.com/cann/ops-transformer/pull/9834
WB-074	【训练开发部】minimax-h3模型训练gpu npu精度未对齐	index_select	1.index_select 在反向梯度累加过程中，NPU 会将计算升精至 FP32，而 GPU 不	https://gitcode.com/cann/ops-nn/pull/1562
WB-076	【训练开发部】dpskv4-flash-vision训推不一致		1、actor 和 ref 的 mHC 配置差异 2、vLLM 与 Megatron 的视觉计算实现	https://gitcode.com/cann/ops-math/pull/6026; https://gitcode.com/cann/ops-math/pull/6030
WB-077	【移动】minimax H3模型训练loss和gpu差异大		host scalar fp32 * device bf16这种场景下，npu是bf16去算的，gp	https://gitcode.com/cann/ops-math/pull/6026; https://gitcode.com/cann/ops-math/pull/6030

2.2 无 GitCode 的故障记录（47 条，简要索引）

无 GitCode ≠ 无故障；以下保留 WB、描述、算子、已有 Wiki/DTS 与证据状态，供 Codex 后续处理，不在本轮展开技术分析。

WB	描述	算子	已有证据	证据状态
WB-003	【华为云】onnx在910B3上转om后精度没问题，但在310P上转om后推理掉到四		Wiki:有	待后续处理
WB-004	蚂蚁ds-r1 0528权重推理偶现推理结果复读		Wiki:无	仅周报/UNKNOWN
WB-005	蚂蚁ring-1T模型vllm推理出现NaN		Wiki:无	仅周报/UNKNOWN
WB-006	【联通】推理服务化长稳精度问题		Wiki:无	仅周报/UNKNOWN
WB-007	【ZJ】智创qwen-vl 2b grad norm 偶现nan	npu_rms_norm / npu_pat	Wiki:无	仅周报/UNKNOWN
WB-008	【训练开发部】dsv3低精度预训练loss差异大		Wiki:无	仅周报/UNKNOWN
WB-011	【美团】fsdp训练loss nan	histc	Wiki:有	待后续处理
WB-012	【南京悠阔电气】图像配准小模型精度异常	softmax / equal算子 / on	Wiki:有	待后续处理
WB-013	【北京电信AI中心】flux文生图模型精度问题		Wiki:无	仅周报/UNKNOWN
WB-014	【电信】小模型精度从argmax减小，达不到整网标准	argmax / conv2d / onnx	Wiki:无	仅周报/UNKNOWN
WB-015	【TX】A3 deepSeek 大EP精度问题		Wiki:有	待后续处理
WB-016	【智谱】GLM-4-32B-0414-w8a16量化精度问题	ROPE	Wiki:有；DTS:DTS2026013018964	待后续处理
WB-017	【需求】310B qwen3精度问题		Wiki:无	仅周报/UNKNOWN
WB-018	【TX】MLA算子精度问题	MLA	Wiki:有	待后续处理
WB-019	【BOSS客户】【MindIE 2.1.RC1.B050】 版本测试 aime 精度		Wiki:有	待后续处理
WB-020	B080版本qwen，llama等模型blooq和ceval精度批量不达标		Wiki:无；DTS:DTS2026062725071	待后续处理
WB-021	思必驰vllm推理评分相比gpu差异过大	exponential_	Wiki:有	待后续处理
WB-022	【客户】：太平洋保险  【版本】：MindIE 2.0.RC1	HCCL	Wiki:无；DTS:DTS2026021221994	待后续处理
WB-024	【蚂蚁】【vLLM-Omni】Qwen-Image-Edit		Wiki:有	待后续处理
WB-026	【腾讯】【vllm】【A5】Qwen3.5	npu_causal_conv1d_cust	Wiki:无；DTS:DTS2026040121354	待后续处理
WB-030	【推理开发部】【vllm】【A5】DeepSeek-V4-Flash	torch_npu.npu_transpos	Wiki:有	待后续处理
WB-031	【腾讯】【vllm】【A5】HY-V3	qkv_rmsnorm_rope	Wiki:有；DTS:DTS2026032818617	待后续处理
WB-035	【腾讯】【vllm】【A5】HY-V3	rope	Wiki:有；DTS:DTS2026090816056	待后续处理
WB-037	A5 MiniMax-M3精度对齐	qkv_rmsnorm_rope	Wiki:有；DTS:DTS2026032818617	待后续处理
WB-039	fg-clip2 纯模型推理精度比cpu差	setitem	Wiki:无	仅周报/UNKNOWN
WB-040	【智源/推理】模型推理token序列在bs2对齐，bs1不对齐	matmul / MATMUL	Wiki:无；DTS:DTS2026020916889	待后续处理
WB-041	【蚂蚁】Ling-V2.5 首步反向gnorm nan	mla	Wiki:有	待后续处理
WB-043	【MY】qwen-image-edit模型basecase		Wiki:有	待后续处理
WB-045	【MT】推荐模型训练A5送测效果不达标	cat算子	Wiki:有；DTS:DTS2606150004403	待后续处理
WB-048	【ZJ】M12模型训练单机/多机gnorm Nan	prepare_wy_repr	Wiki:有	待后续处理
WB-050	【ZJ】M8模型确定性固定不住		Wiki:有	待后续处理
WB-051	【MY】dsv3.2 grpo长稳训崩	rope	Wiki:有；DTS:DTS2026013018964	待后续处理
WB-052	腾讯，Qwen3.5	npu_causal_conv1d_cust	Wiki:无；DTS:DTS2026040121354	待后续处理
WB-053	【训练开发部】A5训练送测	setitem	Wiki:有	待后续处理
WB-054	【训练开发部】A5训练送测	sum算子	Wiki:有；DTS:DTS2026062725071	待后续处理
WB-055	【训练开发部】A5训练送测	embedding / scatter /	Wiki:有；DTS:DTS2026072226197	待后续处理
WB-058	【美团】fsdp训练loss nan	histc	Wiki:无	仅周报/UNKNOWN
WB-059	【蚂蚁】xxx训练gnorm nan		Wiki:有	待后续处理
WB-060	【训练开发部】dsv4-RL logpdiffmean 跳变	npu_transpose_batchmat	Wiki:无	仅周报/UNKNOWN
WB-061	【MY】GLM5	npu_swiglu / RoPE	Wiki:有	待后续处理
WB-062	【腾讯】HY-V3	qkv_rmsnorm_rope	Wiki:有；DTS:DTS2026032818617	待后续处理
WB-063	【腾讯】【龙虾】GLM 5	quant_sparse_flash_att	Wiki:有	待后续处理
WB-066	【zj】xxx gnorm跑飞		Wiki:无	仅周报/UNKNOWN
WB-067	【TX】HY-V3		Wiki:有	待后续处理
WB-068	【TX】HY-V3	rope	Wiki:有；DTS:DTS2026090816056	待后续处理
WB-069	【京东】verl后rollout的结果有乱码,vllm单推结果正常问题	embedding / rope / mla	Wiki:无；DTS:DTS2026090816056	待后续处理
WB-075	【MY】Qwen3.5 SFT gnorm为NaN	solve_tri	Wiki:有	待后续处理

2.3 事件重复与排除记录

8 组周报内部重复（同一故障跨 Sheet 重复登记）：

组	记录	机理
10/47	WB-010 / WB-047	M12 rmsnorm host-tiling-cache
31/62	WB-031 / WB-062	qkv_rmsnorm_rope 图模式
32/63	WB-032 / WB-063	quant_sparse_flash_attention mxfp8
34/67	WB-034 / WB-067	FP8 Attention V scale
11/58	WB-011 / WB-058	美团 fsdp / histc
25/46	WB-025 / WB-046	联通 Qwen3-Embedding
33/64	WB-033 / WB-064	腾讯 all_reduce
26/52	WB-026 / WB-052	腾讯 causal_conv1d

排除记录（3 条，保留理由）：美的 GLM-5（框架特性开关，非单算子）；内存 r13（group list 参数错误）；闭环 r8（金山 SFT 脚本）。

Part 3　27 个 GitCode PR 技术分析

3.1 采集与结构说明

对每个 PR 经 Edge CDP 打开 <repo>/pull/<n>/diffs，抓取「文件改动」正文（文件清单 + +/− + hunk 函数上下文），并抽取新增/删除代码行。结论分级：PR 声明 / Diff 证明 / 测试证明 / 周报声明 / 推导 / UNKNOWN。完整 Diff 原文见 work/handoff_tables/pr_diff_bodies.txt。

3.2 逐 PR 技术分析（统一字段）

计数说明：本小节共 22 个条目，覆盖 27 个 PR——其中 5 组是「同一修复的两个分支」，合并为 1 条（#6026/#6030、#12509/#12716、#8365/#8367、#8443/#8445、#8448/#8458）。22 + 5 = 27。

P01 · Ascend/MindIE-SD#548　组 G10｜对应 WB-038

• 标题：[Bugfix][ops]修复调频plugin异步执行资源管理问题
• 修改位置：csrc/plugin/frequency_regulator.cpp（+11/−132）
• 修改前：namespace 静态封装 + FREQUENCY_REGULATOR_OUTPUT_NUMEL（−132 行）
• 修改后：重写为 at::Tensor frequency_regulator_impl_npu(int64_t freq)，引入 NPUFormat.h/OpAdapter.h
• 失效机理：调频 plugin 异步执行资源管理错误导致 coredump
• 触发条件：frequency_regulator 算子接入后调用
• 测试：Diff 无测试文件
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P02 · Ascend/op-plugin#4833　组 G5/G11｜对应 WB-028

• 标题：fix: correct grad_probs dtype in npu_moe_token_unpermute_grad
• 修改位置：op_plugin_functions.yaml、_meta_registrations.py、测试×2（+105/−3）
• 修改前：dtype 用 grad_unpermuted_tokens；empty_like(probs, dtype=grad_unpermuted_tokens.dtype)
• 修改后：dtype 改为 probs->scalar_type()（有 probs 时）；empty_like(probs, dtype=probs.dtype)
• 失效机理：grad_probs 的 dtype 未跟随 probs，混合精度时输出错误
• 触发条件：probs 与 grad_unpermuted_tokens dtype 不同
• 测试：新增 test_npu_moe_token_unpermute_grad_mixed_dtype + fake-tensor 测试
• 修复验证：PR 声明+测试证明
• 证据等级：测试证明

P03 · cann/ascend-transformer-boost#2094　组 G7｜对应 WB-001/010/047/057

• 标题：fix 950 rmsnorm golden
• 修改位置：tests/framework/python/CsvOpsTestTool/data_generation.py::RmsNormOperation（+17/−0）
• 修改前：无 Ascend950 分支
• 修改后：新增 if get_soc_version()=="Ascend950" + quantType 分支
• 失效机理：测试 golden 修正（周报根因为 aclnn rmsnorm host-tiling-cache 缓存键混用）
• 触发条件：同一 rmsnorm 连续/非连续输入多次执行
• 测试：该文件即测试数据生成
• 修复验证：PR 声明+Diff 证明（测试侧）
• 证据等级：Diff 证明（测试侧，非 kernel 修复，需人工确认是否对应周报根因）

P04 · cann/ascend-transformer-boost#2207　组 G9｜对应 WB-071

• 标题：fix name spelling error
• 修改位置：example/op_demo/ring_mla/*、include/atb/infer_op_params.h、docs、set_env.sh（+31/−28）
• 修改前：命名拼写/文档路径
• 修改后：命名拼写修正 + 文档/set_env 路径更新
• 失效机理：标题与周报根因（ring_mla/MLA 推理乱码）不一致
• 触发条件：—
• 测试：Diff 无测试
• 修复验证：PR 声明
• 证据等级：DIFF_WEAK / UNKNOWN（需人工复核）

P05 · cann/hccl#1034　组 G10/G3｜对应 WB-023/033/064

• 标题：PCIE协议的时候不使用HcommBatchTransfer
• 修改位置：5 个 ins_temp_*_nhr.cc（all_gather/all_reduce/broadcast/reduce/reduce_scatter）（+7/−7）
• 修改前：SendRecvBatchRead / SendRecvBatchReadReduce / RecvBatchRead
• 修改后：SendRecvRead / SendRecvReadReduce / RecvRead
• 失效机理：PCIE 协议下批量传输(HcommBatchTransfer)路径问题
• 触发条件：PCIE 协议 + NHR 通信模板
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P06 · cann/ops-math#4871　组 G3/G8｜对应 WB-027

• 标题：修复RadixTopK同步错误并预留AscendC API所需workspace
• 修改位置：math/radix_top_k/op_host/*tiling.cpp、op_kernel/radix_top_k_{ub,utils,ws,ws_utils}.h（+97/−86）
• 修改前：未预留 sysWorkspace
• 修改后：GetLibApiWorkSpaceSize() + workspaceSize_ += sysWorkspaceSize；加 SyncAll()/SToVSync()
• 失效机理：缺同步 + workspace 不足
• 触发条件：TopK 分批
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P07 · cann/ops-math#6026 / 6030　组 G4｜对应 WB-076/077

• 标题：fix：reduce prod bool输出改用ReduceAll，对齐GPU逻辑和语义
• 修改位置：math/reduce_prod/op_api/aclnn_prod.cpp（+24/−6，两分支同改）
• 修改前：调用 l0op::ReduceProd(...)
• 修改后：bool 输出场景（910B/910_93）走 ReduceAll，对齐 GPU torch.prod(dtype=bool) 语义
• 失效机理：布尔归约算法语义与 GPU 不一致
• 触发条件：输出 dtype=bool
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P08 · cann/ops-nn#10622　组 G4｜对应 WB-002

• 标题：fix addmm and baddbmm beta = 0, precision error
• 修改位置：matmul/batch_mat_mul_v3/.../aclnn_baddbmm.cpp、mat_mul_v3/.../aclnn_addmm.cpp（+7/−2）
• 修改前：ExecGemmV3WithAlphaBetaOp(..., executor)（未传 enableGemm16In32Out）
• 修改后：bool enableGemm16In32Out = NeedEnableFp32Output(...) 并传入
• 失效机理：beta=0 时 GEMM16In32Out 未开启，FP32 输出精度错误
• 触发条件：beta=0（addmm/baddbmm）
• 测试：PR 描述补充了测试前后结果
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P09 · cann/ops-nn#1562　组 G5｜对应 WB-074

• 标题：修复算子bug&&修改aclnnIndexSelect中的文档
• 修改位置：index/gather_v2/op_api/aclnn_gather_v3.cpp 等（+7/−5）
• 修改前：indexSize = ge::GetSizeByDataType(index->GetDataType())
• 修改后：auto indexSize = 1;（self.shape=[] 时 index.shape 只能 [1]）
• 失效机理：index_select 反向精度 / indexSize 计算
• 触发条件：self 为标量 shape
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P10 · cann/ops-nn#2285　组 G7｜对应 WB-056

• 标题：拦截bias变化导致进入matmul v3kernel bin找不到的问题
• 修改位置：matmul/common/op_host/op_api/matmul_util.cpp（+1/−1）
• 修改前：mmOpInfo.ori_info.self_dtype != mmOpInfo.ori_info.bias_dtype
• 修改后：mmOpInfo.support_info.self_dtype != mmOpInfo.support_info.bias_dtype
• 失效机理：用错 info 结构（ori vs support）导致 kernel bin 选择错误
• 触发条件：bias dtype 变化
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P11 · cann/ops-nn#6170　组 G5/G7｜对应 WB-072

• 标题：repeat_interleave支持边界shape
• 修改位置：index/repeat_interleave/op_api/repeat_interleave.cpp（+14/−1）
• 修改前：仅 AICORE910B_DTYPE_SUPPORT_LIST；xDimNum = x->GetViewShape().GetDimNum()
• 修改后：新增 BIG_SHAPE_DTYPE_SUPPORT_LIST；xViewShape[i] > INT32_MAX_NUM 且 dtype 支持则走 v2
• 失效机理：大 shape（>INT32）边界未支持
• 触发条件：单轴 > INT32_MAX 的 shape
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P12 · cann/ops-nn#7443　组 待核｜对应 WB-032

• 标题：DEBUG: 删除foreach_copy A5
• 修改位置：foreach/foreach_copy/* 等 31 文件（+0/−4653）
• 修改前：删除整套 foreach_copy A5 实现
• 修改后：—
• 失效机理：DEBUG 性删除，非修复
• 触发条件：—
• 测试：—
• 修复验证：—
• 证据等级：UNKNOWN（需人工复核）

P13 · cann/ops-transformer#12509 / 12716　组 G3｜对应 WB-009

• 标题：修复FIA_Kernel同步问题
• 修改位置：attention/incre_flash_attention/op_kernel/arch22/ifa_service_matmul_full_quant.h、incre_flash_attention_preload_mla.h（+754/−619，两分支同改）
• 修改前：FIA kernel 内部同步/参数
• 修改后：FIA kernel 构造函数与同步修正
• 失效机理：FIA kernel 内部同步竞争（周报：FA 算子内部竞争）
• 触发条件：IFA/MLA kernel 路径
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P14 · cann/ops-transformer#2077　组 G2｜对应 WB-042/044/049

• 标题：修复GroupedMatmul切K场景不支持K为0的问题
• 修改位置：gmm/grouped_matmul/op_host/op_api/aclnn_grouped_matmul.cpp、op_tiling/grouped_matmul_tiling.cpp（+56/−8）
• 修改前：切 K 场景无 CheckZeroShapeSplitK
• 修改后：新增 CheckZeroShapeSplitK(...)：zeroM/zeroN → workspaceSize=0
• 失效机理：切 K 场景 K=0（空/零 shape）未处理
• 触发条件：groupType=2 切 K、K=0
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P15 · cann/ops-transformer#3901　组 G1｜对应 WB-065

• 标题：bugfix unaligned scene oom
• 修改位置：attention/flash_attention_score_grad/op_kernel/arch32/flash_attention_score_grad_s1s2_bn2.h（+4/−4）
• 修改前：传参 mm1BaseK
• 修改后：传参 dimD
• 失效机理：不对齐场景 mm base 参数用错 → oom
• 触发条件：s1/s2 不对齐
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P16 · cann/ops-transformer#4152　组 G1/G2｜对应 WB-065

• 标题：FlashAttentionScoreGrad修复空tensor场景oom问题
• 修改位置：.../arch32/flash_attention_score_grad_template_tiling_key.h（+1/−1）
• 修改前：FooBngs1s2BbTilingData
• 修改后：FlashAttentionScoreGradTilingData
• 失效机理：空 tensor 场景 tiling struct 选择错误 → oom
• 触发条件：空 tensor
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P17 · cann/ops-transformer#8365 / 8367　组 G1｜对应 WB-029

• 标题：修复NsaCompAtten内存检测问题
• 修改位置：attention/nsa_compress_attention/op_host/*tiling*、op_kernel/nsa_compress_attention_s1s2_bn2gs1_sab.h（+17/−2）
• 修改前：maxTopkBase = (190*1024-20*S2sizeAlign32)/(4*S2sizeAlign32+8*k_pad)；固定 UB offset
• 修改后：TILING_DATA_FIELD_DEF(tmpUbSize)；用 GetTopKMaxMinTmpSize 动态计算
• 失效机理：TopK UB 大小计算错误 → 内存越界
• 触发条件：TopK tiling（S2/blockSize 变化）
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P18 · cann/ops-transformer#8443 / 8445　组 G3｜对应 WB-070

• 标题：修复SFAG同步问题与潜在风险
• 修改位置：attention/sparse_flash_attention_grad/*（+25/−16）
• 修改前：NzToNd(..., bool isDk=false)
• 修改后：NzToNd(..., event_t eventIdMte2ToV, backEventTmp, backEvent, bool isBackEvent=false) + PIPE_BARRIER(PIPE_V)
• 失效机理：缺少 event 同步
• 触发条件：SFAG bmm vec 路径
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P19 · cann/ops-transformer#8448 / 8458　组 回移｜对应 WB-025/046

• 标题：Revert "A2A3 npu_fused_infer_attention_score 算子支持cache首轴非连续"
• 修改位置：fused_infer_attention_score docs + op_api（+61/−217）
• 修改前：支持 key/value 首轴非连续
• 修改后：回退该支持，恢复约束
• 失效机理：回退修复（cache 首轴非连续支持引起副作用）
• 触发条件：cache 首轴非连续场景
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明（回退）

P20 · cann/ops-transformer#8752　组 G6｜对应 WB-036

• 标题：modify a2 a8w4 workspace k<n/2
• 修改位置：mc2/mega_moe/op_kernel/arch22/mega_moe_a2.h、..._bf16_w4a8.h（+33/−24）
• 修改前：workspace 在 k<n/2 时计算错误
• 修改后：按 k<n/2 修正 workspace
• 失效机理：a8w4 workspace 边界
• 触发条件：k<n/2（a8w4）
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P21 · cann/ops-transformer#8766　组 G6｜对应 WB-036

• 标题：修复mega_moe在K2大于K的时候两个gmmA矩阵复用导致的问题
• 修改位置：mc2/mega_moe/op_host/op_tiling/arch22/mega_moe_tiling_arch22.cpp、op_kernel/arch22/mega_moe_kernel_a3.h（+23/−10）
• 修改前：K2>K 时两个 gmmA 矩阵复用
• 修改后：避免 gmmA 矩阵复用
• 失效机理：gmmA 矩阵复用错误
• 触发条件：K2>K
• 测试：Diff 无测试
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

P22 · cann/ops-transformer#9834　组 G1｜对应 WB-073

• 标题：LI UB duplicate fix
• 修改位置：attention/lightning_indexer/op_kernel/arch35/lightning_indexer_service_vector.h（+9/−7）
• 修改前：InitBuffers/ProcessTopK UB 重复分配
• 修改后：修正 UB 重复分配
• 失效机理：lightning_indexer UB 重复分配（内存踩踏）
• 触发条件：LI arch35
• 测试：PR 为周报原直链
• 修复验证：PR 声明+Diff 证明
• 证据等级：Diff 证明

3.3 按 A–G 机理组的技术总结

组	机理	相关 PR	技术总结
A 内存踩踏/越界	G1	#8365/#8367、#9834、#3901、#4152	NsaCompAtten 动态算 UB、LI 去重 UB、FA grad 传参 mm1BaseK→dimD、空 tensor tiling struct 修正
B 同步缺失	G3	#12509/#12716、#8443/#8445、#4871	FIA/SFAG kernel 补 event/PIPE_BARRIER、RadixTopK 加 SyncAll/SToVSync
C 浮点累加序/数值策略	G4	#10622、#6026/#6030	beta=0 走 GEMM16In32Out、bool reduce 改 ReduceAll 对齐 GPU
D dtype/精度转换	G5	#4833、#1562、#6170	grad_probs dtype 跟随 probs、indexSize=1、大 shape dtype 列表
E 量化/反量化	G6	#8752、#8766	a8w4 workspace k<n/2、mega_moe gmmA 矩阵复用
F tiling/形状/融合	G7	#2094、#2285、#6170	rmsnorm 测试 golden（Ascend950）、bias dtype 用 support_info、大 shape 支持
G 回移/未定界	G8/G10	#1034、#548、#2207、#7443、#8448/#8458	HCCl PCIE 路径、调频 plugin 资源、命名修正（标题与根因不一致）、DEBUG 删除、cache 首轴非连续回退

3.4 3 个 Issue + 1 个 Commit（单独记录，非 PR）

目标	类型	对应 WB	可用内容	状态
cann/ops-cv#297	Issue	WB-009	UpsampleBicubic2dAAGrad 特定 shape 精度 fail	无 Diff（Issue）
cann/ops-math#681	Issue	WB-011	torch.histc 用例与标杆对比存在精度问题	无 Diff（Issue）
cann/ops-transformer#604	Issue	WB-018	FAG sink 精度异常	无 Diff（Issue）
ops-transformer commit 0a9e975f…	Commit	WB-034	FP8 Attention V scale（周报原直链）	DIFF_UNAVAILABLE（页面未渲染）

Part 4　事件去重

同一事件可有多来源（周报/Wiki/DTS/PR），只计一个事件。

• 周报内部 8 组重复：见 Part 2.3。
• 同一 PR 被多故障引用（事件可能同一或同族）：#2094←WB-001/010/047/057；#2077←WB-042/044/049；#1034←WB-023/033/064；#8448/#8458←WB-025/046；#6026/#6030←WB-076/077；#12509/#12716←WB-009。
• 回移 / 跨分支：#8448 与 #8458 为同一 Revert 的两个分支；#6026 与 #6030 为同一修复的两个分支；#12509 与 #12716 同一修复；#8365 与 #8367 同一修复；#8443 与 #8445 同一修复。
• 仅周报、无任何外部证据（16 条）：WB-004/005/006/007/008/015/017/034/038/041/043/050/058/059/060/063。

Part 5　失效机理分组与潜在模式候选

下表 = 周报内部归纳的候选机理，尚未与原 30 条模式正式对照；同组可合并为同一模式明细，不同组不得因算子名相同合并。

机理组	失效机理	代表故障（WB）	PR 证据	候选模式
G1	内存踩踏/越界	WB-029、WB-073、WB-009、WB-065	#8365/#8367、#9834、#12509/#12716、#3901/#4152	C1
G2	空 tensor/退化输入未处理	WB-042、WB-044、WB-048、WB-049	#2077、#4152	C2
G3	同步缺失/核间竞争	WB-009、WB-029、WB-070	#12509/#12716、#8443/#8445、#4871	待进一步比较
G4	浮点累加序/数值策略不一致	WB-002、WB-033、WB-064、WB-040	#10622、#6026/#6030、#1034	C6
G5	dtype/精度转换差异	WB-072、WB-074、WB-077、WB-024、WB-043	#6170、#1562、#4833	待进一步比较
G6	量化/反量化位置或类型	WB-034、WB-036、WB-067	#8752、#8766	C4、C5
G7	tiling/缓存键/形状边界	WB-010、WB-047、WB-057、WB-056、WB-053	#2094、#2285	C3
G8	融合算子实现差异	WB-011、WB-027、WB-061	#4871、#7443（待核）	待进一步比较
G9	rope/位置编码实现差异	WB-016、WB-031、WB-035、WB-051、WB-062、WB-068、WB-069	无独立 PR（框架/包修复）	待进一步比较
G10	硬件/通信/平台	WB-018、WB-022、WB-023、WB-038、WB-054	#1034、#548	待进一步比较
G11	索引/元数据语义	WB-027、WB-028	#4833、#4871	待进一步比较

候选模式说明（C1–C7，尚未与 30 条模式对照）：

候选	失效机理差异点	直接证据	建议
C1 内存踩踏型越界	算子内部 GM 越界导致下游 NaN（非 shape 错误）	WB-029/073；#8365/#8367/#9834	优先补库，并与「越界读写」族细分
C2 空 tensor 输出未初始化	0 元素输入输出未写、保留 empty 脏数据	WB-044/049；#2077/#4152	与「空 tensor 处理不当」对比后决定合并/扩展
C3 tiling 缓存键错误	host-tiling-cache 用错缓存键（非 tiling 切分）	WB-010/047/057；#2094	与「tiling 切分策略」区分
C4 FP8 静态量化 V scale 读取错误	attention 对 V scale 读取路径错误	WB-034/067；#8752	量化族新明细候选
C5 mxfp8 KV 与融合算子类型不匹配	稀疏注意力仅支持 FP8，mxfp8 未拦截	WB-032/063；#8766	量化族新明细候选
C6 reduce prod 布尔语义与 GPU 不一致	布尔归约用错 reduce 算法	#6026/#6030	语义类候选
C7 foreach_copy A5 大批量删除	31 文件调试改动	#7443	UNKNOWN，需人工复核

Part 6　未解决故障与证据缺口

类别	数量	明细
仅周报、无任何外部证据	16	WB-004/005/006/007/008/015/017/034/038/041/043/050/058/059/060/063
无 GitCode 的故障记录	47	见 Part 2.2（含 Wiki 19 / Wiki+DTS 10 / DTS 6 / 无外部链接 12）
GitCode 无 Diff	4	3 Issue（#297/#681/#604）+ 1 Commit（0a9e975，DIFF_UNAVAILABLE）
标题/根因不一致或回移，需人工复核	3	ATB#2207（仅改名）、ops-nn#7443（DEBUG 删除）、#8448/#8458（回退）
#NAME? 根因（无法解析）	1	WB-055
UNKNOWN / PARTIAL 保留	全部	证据不足处不臆断，保持 UNKNOWN

Part 7　来源索引

7.1 输入文件（相对项目根）

文件	Sheet/行	用途
数据/26年精度工厂周报.xlsx	9 个故障 Sheet	原始周报（26 Sheet）
数据/算子问题筛选/周报全表_故障清单.csv	WB-001～267	267 条统一清单（含 Sheet/Excel行/链接）
数据/算子问题筛选/算子故障_证据与补库清单.csv	77 条	逐条证据字段（本文件 Part 2 来源）
数据/outputs/周报算子相关用例_CANN故障模式归类_V4_20261108.xlsx	62 用例	V4/证据链接清单
数据/trigger_library(1).md	42 项	API 输入构造清单（参考，未做正式分类）
数据/算子问题筛选/算子故障逐条说明.md	77 条	逐条原文证据

7.2 GitCode 证据路径

项	路径
Diff 快照（31）	work/gitcode_diff/*.json
Diff 原文汇总	work/handoff_tables/pr_diff_bodies.txt
PR 分析表	work/handoff_tables/table_pr_analysis.md
SHA-256 清单	work/handoff_tables/SHA256SUMS.tsv

7.3 PR URL 与本地 Diff 映射（节选：全部 27 条见 work/gitcode_diff/）

PR URL	本地 Diff JSON
https://gitcode.com/Ascend/MindIE-SD/pull/548	work/gitcode_diff/Ascend__MindIE-SD_pull_548.json
https://gitcode.com/Ascend/op-plugin/pull/4833	work/gitcode_diff/Ascend__op-plugin_pull_4833.json
https://gitcode.com/cann/ascend-transformer-boost/pull/2094	work/gitcode_diff/cann__ascend-transformer-boost_pull_2094.json
https://gitcode.com/cann/ascend-transformer-boost/pull/2207	work/gitcode_diff/cann__ascend-transformer-boost_pull_2207.json
https://gitcode.com/cann/hccl/pull/1034	work/gitcode_diff/cann__hccl_pull_1034.json
https://gitcode.com/cann/ops-math/pull/4871	work/gitcode_diff/cann__ops-math_pull_4871.json
https://gitcode.com/cann/ops-math/pull/6026	work/gitcode_diff/cann__ops-math_pull_6026.json
https://gitcode.com/cann/ops-nn/pull/10622	work/gitcode_diff/cann__ops-nn_pull_10622.json
https://gitcode.com/cann/ops-nn/pull/1562	work/gitcode_diff/cann__ops-nn_pull_1562.json
https://gitcode.com/cann/ops-nn/pull/2285	work/gitcode_diff/cann__ops-nn_pull_2285.json
https://gitcode.com/cann/ops-nn/pull/6170	work/gitcode_diff/cann__ops-nn_pull_6170.json
https://gitcode.com/cann/ops-nn/pull/7443	work/gitcode_diff/cann__ops-nn_pull_7443.json
https://gitcode.com/cann/ops-transformer/pull/12509	work/gitcode_diff/cann__ops-transformer_pull_12509.json
https://gitcode.com/cann/ops-transformer/pull/2077	work/gitcode_diff/cann__ops-transformer_pull_2077.json
https://gitcode.com/cann/ops-transformer/pull/3901	work/gitcode_diff/cann__ops-transformer_pull_3901.json
https://gitcode.com/cann/ops-transformer/pull/4152	work/gitcode_diff/cann__ops-transformer_pull_4152.json
https://gitcode.com/cann/ops-transformer/pull/8365	work/gitcode_diff/cann__ops-transformer_pull_8365.json
https://gitcode.com/cann/ops-transformer/pull/8443	work/gitcode_diff/cann__ops-transformer_pull_8443.json
https://gitcode.com/cann/ops-transformer/pull/8448	work/gitcode_diff/cann__ops-transformer_pull_8448.json
https://gitcode.com/cann/ops-transformer/pull/8752	work/gitcode_diff/cann__ops-transformer_pull_8752.json
https://gitcode.com/cann/ops-transformer/pull/8766	work/gitcode_diff/cann__ops-transformer_pull_8766.json
https://gitcode.com/cann/ops-transformer/pull/9834	work/gitcode_diff/cann__ops-transformer_pull_9834.json
https://gitcode.com/cann/ops-math/pull/6030	work/gitcode_diff/cann__ops-math_pull_6030.json
https://gitcode.com/cann/ops-transformer/pull/12716	work/gitcode_diff/cann__ops-transformer_pull_12716.json
https://gitcode.com/cann/ops-transformer/pull/8367	work/gitcode_diff/cann__ops-transformer_pull_8367.json
https://gitcode.com/cann/ops-transformer/pull/8445	work/gitcode_diff/cann__ops-transformer_pull_8445.json
https://gitcode.com/cann/ops-transformer/pull/8458	work/gitcode_diff/cann__ops-transformer_pull_8458.json

全部 27 个 PR 的 Diff JSON 均在 work/gitcode_diff/；3 个 Issue（...__issues__297/681/604.json）与 1 个 Commit（cann__ops-transformer_commit_0a9e975f….json）另存，无 Diff。

Part 8　Codex Init / Expansion 建议

1. 优先审查补库记录：Part 2.1 有 GitCode 的 30 条 + Part 5 的 C1–C7 候选。
2. 检查 C1–C7 是否与已有模式重复：本文件未与 30 条模式对照，需结合 Agent 1 Baseline 判定 COVERED/EXTEND/NEW_CANDIDATE/RELATED/UNKNOWN。
3. 对 3 个 PR 保留人工复核：ATB#2207、ops-nn#7443、#8448/#8458。
4. UNKNOWN 不自动归类：16 条仅周报记录、3 Issue + 1 Commit、#NAME?。
5. 不自动合并或删除旧模式；拆分/合并只出建议。
6. 结合 Agent 1 的 Baseline 执行正式 Init/Expansion；不修改生产 state，不执行 Init/ACCEPT/冻结。

不重新采集已取得 Diff；不修改生产 state；不自动新增、合并或删除模式。