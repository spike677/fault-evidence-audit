# CANN 30条模式数据 Init 验收报告

日期：2026-11-10。本轮在上一轮草案上完成独立的数据 Init，不调用生产 Workflow。

**30/30 INITIALIZED。SOURCE_VERIFIED 为0/30；HARDWARE_VALIDATED 为0/30。**

数据完整性与证据确认分开统计。9条上游未确认模式全部保留，缺少原始网页或Diff不阻塞初始化。本次只依赖两份Markdown中的声明、摘要和引用；没有继续搜索快照目录，也没有等待现场传输。

## 1. 完成数量与输入

| 项目 | 数量/状态 |
| --- | --- |
| 数据 Init | 30 INITIALIZED；0 INITIALIZATION_ERROR |
| 原始15逻辑列 | 30/30完整保留文档原文 |
| 历史资料 | 18 Wiki + 10 DTS整理记录（其中D10仅权限/UNKNOWN元信息）；29个模式×资料来源对 |
| 周报及GitCode | 77条原记录；27 PR（22个分析块）、3 Issue、1 Commit |
| G/C完整性 | G1–G11、C1–C7均在全文中核对；不作为正式模式导入 |
| 证据实体/关系 | 136 / 253，SOURCE/EVENT/MODE分开 |
| 正式新增/人工ACCEPT/冻结 | 0 / 0 / 未冻结 |

- 输入A：`D:\project\demoncatpfi\数据\CANN_30_MODES_WIKI_DTS_BASELINE_20261110.md`；SHA-256 `592f0231669a8c4548860fec294daa79b0e521c3392c663bf12d70a3808dd43c`；201519 bytes，全文UTF-8读取，最长行86028字符。

- 输入B：`D:\project\demoncatpfi\数据\CANN_WEEKLY_GITCODE_FAULT_SCREENING_20261110.md`；SHA-256 `ee37823b2b3d77f8b767748818cf63dcc2fdb5a00316bff1317d6520f13c2e09`；38002 bytes，全文UTF-8读取，最长行199字符。

复用旧版已解析的原字段和字符锚点，并逐个对照当前完整文本；未重新生成旧版7份核心交付。原42、V4和生产Schema均不改。

“原始15列完整”指与这两份Markdown提供的15个逻辑字段一致。上游O–S案例列已合并、URL已脱敏，本轮保留这些原值，不虚构五个物理单元格或内网URL。原工作簿的Sheet、行、单元格及SHA按文档记录，均标明未独立核验。

## 2. 初始化和证据状态

| 模式定义状态 | 模式数 |
| --- | --- |
| PARTIALLY_SUPPORTED | 6 |
| REFINED_WITH_EVIDENCE | 13 |
| UNCONFIRMED | 11 |

证据状态允许多选，以下数量不能相加当作模式数量：

| 证据状态 | 唯一mode_id数 |
| --- | --- |
| MISSING_EVIDENCE | 15 |
| ORIGINAL_SOURCE_RECORDED | 30 |
| SOURCE_TEXT_NOT_INDEPENDENTLY_VERIFIED | 30 |
| SUMMARY_AVAILABLE | 26 |

`REFINED_WITH_EVIDENCE`仅指根据文档摘要完善模式定义，不表示本轮独立核验原文。`PARTIALLY_SUPPORTED`可以表示仅有现象支持；`UNCONFIRMED`仍保留原定义和本轮规范化说明。

ORIGINAL_MODE_DECLARATION、WIKI_SUMMARY、DTS_SUMMARY、GITCODE_ANALYSIS_SUMMARY、MODEL_DERIVED和UNKNOWN分别保存。只有文档明确标记“原文”的短语才列为VERBATIM_EXCERPT，而且仍不宣称已核验原网页。

## 3. 30条逐项 Init 清单

| ID | 名称 | Sheet/行 | Init | 定义状态 | 摘要审查 | 资料 |
| --- | --- | --- | --- | --- | --- | --- |
| M001 | 算子实现精度不一致：低精度误差累积 | 芯片使能（CANN）/10 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W01 |
| M002 | 边界值异常 | 芯片使能（CANN）/27 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W02 |
| M003 | tiling切分策略的逻辑异常 | 芯片使能（CANN）/25 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W03 |
| M004 | 越界读写：偏移量计算错误 | 芯片使能（CANN）/6 | INITIALIZED | UNCONFIRMED | SUMMARY_INTERNAL_CONFLICT | A-D07 |
| M005 | 浮点数累加序不当 | 芯片使能（CANN）/12 | INITIALIZED | PARTIALLY_SUPPORTED | SYMPTOM_ONLY | A-D06 |
| M006 | 越界读写：shape错误 | 芯片使能（CANN）/4 | INITIALIZED | UNCONFIRMED | SYMPTOM_ONLY | A-D02 |
| M007 | 缺少同步 | 芯片使能（CANN）/7 | INITIALIZED | PARTIALLY_SUPPORTED | SYMPTOM_ONLY | A-D05 |
| M008 | 浮点数累加序不当 | 芯片使能（CANN）/16 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W04 |
| M009 | 精度溢出：数值格式精度不够导致精度溢出 | 芯片使能（CANN）/20 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W05 |
| M010 | 融合算子反量化位置不当 | 芯片使能（CANN）/28 | INITIALIZED | UNCONFIRMED | NO_HISTORICAL_LINK |  |
| M011 | tiling切分策略分支错误 | 芯片使能（CANN）/14 | INITIALIZED | PARTIALLY_SUPPORTED | SYMPTOM_ONLY | A-D09 |
| M012 | 确定性计算未实现 | 芯片使能（CANN）/15 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W06；A-W07 |
| M013 | NPU适配引入额外参数 | 芯片使能（CANN）/18 | INITIALIZED | UNCONFIRMED | SYMPTOM_ONLY | A-D01 |
| M014 | tensor下标超出数值范围 | 芯片使能（CANN）/19 | INITIALIZED | UNCONFIRMED | NO_HISTORICAL_LINK |  |
| M015 | 越界读写：内存踩踏覆盖 | 芯片使能（CANN）/23 | INITIALIZED | UNCONFIRMED | CONFLICTING_ATTRIBUTION | A-W08 |
| M016 | 精度溢出：特定硬件数值格式导致精度溢出 | 芯片使能（CANN）/26 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W09 |
| M017 | tiling切分策略不同分支处理精度不一致 | 芯片使能（CANN）/30 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W10 |
| M018 | 浮点数累加序不当 | 芯片使能（CANN）/32 | INITIALIZED | UNCONFIRMED | UNRESOLVED_MECHANISM | A-W11 |
| M019 | 数学等价但计算结果不等价 | 芯片使能（CANN）/11 | INITIALIZED | UNCONFIRMED | NO_HISTORICAL_LINK |  |
| M020 | 空tensor处理不当 | 芯片使能（CANN）/3 | INITIALIZED | PARTIALLY_SUPPORTED | SUMMARY_PARTIAL | A-W12 |
| M021 | 矩阵乘加融合后数据格式转换精度丢失 | 芯片使能（CANN）/31 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W13 |
| M022 | 搬运逻辑错误：blocktable有错误 | 芯片使能（CANN）/8 | INITIALIZED | UNCONFIRMED | SYMPTOM_ONLY | A-D04 |
| M023 | tiling切分策略的逻辑异常 | 芯片使能（CANN）/13 | INITIALIZED | UNCONFIRMED | BODY_UNAVAILABLE | A-D10 |
| M024 | 数据排布转换错误 | 芯片使能（CANN）/9 | INITIALIZED | PARTIALLY_SUPPORTED | SYMPTOM_ONLY | A-D08 |
| M025 | 算子实现精度不一致：指数函数精度实现错误 | 芯片使能（CANN）/21 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W14 |
| M026 | 越界读写：tiling切分策略的逻辑错误 | 芯片使能（CANN）/5 | INITIALIZED | UNCONFIRMED | SYMPTOM_ONLY | A-D03 |
| M027 | 竞品实现不一致：特定私有数据排列格式 | 芯片使能（CANN）/24 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W15 |
| M028 | 确定性计算未实现 | 芯片使能（CANN）/22 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W16 |
| M029 | 硬件导致算子不支持未拦截 | 芯片使能（CANN）/17 | INITIALIZED | PARTIALLY_SUPPORTED | MULTI_SUBCLAIM_PARTIAL | A-W08；A-W17 |
| M030 | 输入数据类型强转低精丢失 | 芯片使能（CANN）/29 | INITIALIZED | REFINED_WITH_EVIDENCE | SUMMARY_SUPPORTS | A-W18 |

## 4. 模式定义、触发条件和资料明细

### M001 算子实现精度不一致：低精度误差累积

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：混合精度模式下npu和gpu的实现行为不一致，如混精下gpu默认先转fp32再计算，npu先fp16计算再转fp32，单算子相同输入gpu侧输出可以正常（超fp16没超fp32）npu溢出
- 来源：输入A，芯片使能（CANN）!F10（文档记录），`SRC-c7807e71337064e3f929d7a1`。
- 规范化机理：混精路径的类型提升顺序不同：GPU先提升至FP32再计算，NPU在低精度计算后再提升，可能先产生溢出或误差。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 混合精度算子计算路径（历史摘要为prod） | MODEL_DERIVED | SRC-c7807e71337064e3f929d7a1 |
| 表现 | 混精训练容易lossNAN | ORIGINAL_MODE_DECLARATION | SRC-96e00b645bbc9c2275544643 |
| 输入条件 | 混精训练中 FP16 输入路径（如 prod/matmul） | MODEL_DERIVED | SRC-743b2dba79d604c9e93778cc |
| 执行条件 | 混合精度训练开关；未设置输入转 FP32 的处理 | MODEL_DERIVED | SRC-13a349731c10b85c4714d552 |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-0ee1fa3cd0567ad4b4c5c2cc |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-9ee3b9d356c35769777f5db4 |

**A-W01 开源SparseTrack模型梯度溢出后几百步Loss NaN**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | fp16 稳定溢出、bf16 改善仍有、GPU 不溢出；loss 几百步后 NaN |
| 触发 | 混精训练，输入 float16 输出 float32 |
| 定位 | 单算子复现 + profiling 确认先算后转 |
| 根因 | 混精下 NPU 与 GPU 的 prod 行为不一致：GPU 先 fp16→fp32 再算，NPU 先 fp16 算再转 fp32 |
| 处理/修复 | torch 侧把 prod 输入转 fp32 规避（框架/算子侧未改） |
| 验证 | 规避后正常；框架/算子侧未闭环 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-47c2372cc6ce9ffa0274229a |

相近周报索引：WB-002, WB-008, WB-072, WB-074, WB-076, WB-077。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 尚无本机历史正文及精确shape/数值域；不能由此确认每个同算子事件。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M002 边界值异常

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：INTrainingUpdataV2算子variance算出来有负值，导致开根后变为nan
- 来源：输入A，芯片使能（CANN）!F27（文档记录），`SRC-2b49dafe78f0f09e7f7f699a`。
- 规范化机理：方差计算结果出现负值，随后开平方产生NaN。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | INTrainingUpdataV2 / InstanceNormalization | MODEL_DERIVED | SRC-2b49dafe78f0f09e7f7f699a |
| 表现 | 输出异常nan值 | ORIGINAL_MODE_DECLARATION | SRC-c63a394b78b4f614598f86fe |
| 输入条件 | 纯黑/大部分为 0 的输入（in1 大部分为 0） | MODEL_DERIVED | SRC-70c125af836c9f368eded7a2 |
| 执行条件 | onnx→om 离线推理 | MODEL_DERIVED | SRC-0ac30b84760152b73a63303c |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-a705033f0728c02b17c4b91c |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-5213f762f51acf1acdaa0549 |

**A-W02 【客户已脱敏】om模型输入纯黑图像输出为nan**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 纯黑图像输入输出 NaN，掉背景 |
| 触发 | in1 大部分为 0 的输入 |
| 定位 | 纯黑真实数据 debug compare |
| 根因 | INTrainingUpdataV2 的 variance 算出负值，开根后 NaN |
| 处理/修复 | 算子侧修改把负值改为 0（规避） |
| 验证 | 规避后 NaN 消除、精度比对正常 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-b328149bd75306822dfe3009 |

相近周报索引：WB-005, WB-012。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 方差公式、负值阈值及修复代码未取得。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M003 tiling切分策略的逻辑异常

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：reduce轴没有切多核，但m轴在多batch下切分不同，由于FA是下三角的sparse计算，导致核内的reduce轴切分粒度不同
- 来源：输入A，芯片使能（CANN）!F25（文档记录），`SRC-a54baa324f56cf730d2392af`。
- 规范化机理：m轴随batch改变切分，改变核内reduce粒度和计算顺序，导致单/多batch结果差异。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | FA/FIA下三角sparse计算 | MODEL_DERIVED | SRC-a54baa324f56cf730d2392af |
| 表现 | 单batch、多batch输出不一致 | ORIGINAL_MODE_DECLARATION | SRC-3d85996bd2409e40316e9d50 |
| 输入条件 | 多 batch 推理（同一 query） | MODEL_DERIVED | SRC-14c9a485cb71746db2cde018 |
| 执行条件 | 图模式推理 + 融合算子 | MODEL_DERIVED | SRC-9bc01547447684902abeaa34 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-a9e4e0e1ae0404156170f732 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-95656b6ce10a803e28190034 |

**A-W03 盘古pt图模式多batch与单batch不一致**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 单 batch 与多 batch 相同输入第一个 token logits 不一致 |
| 触发 | 多 batch 推理 + 图模式融合 |
| 定位 | msprobe/msit dump，FIA 单算子复现 |
| 根因 | reduce 轴未切多核，m 轴多 batch 下切分不同，FA 下三角 sparse 使核内 reduce 切分粒度不同 |
| 处理/修复 | tiling/切分调整（未给最终代码） |
| 验证 | 海思复现并定位 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-15495d4f646a8e2c16a81ec1 |

相近周报索引：暂无。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 不能把同shape、同二进制的随机竞争等同于输入变化后的计算差异。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M004 越界读写：偏移量计算错误

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：window区偏移计算存在问题,导致地址有踩踏，从而导致精度问题
- 来源：输入A，芯片使能（CANN）!F6（文档记录），`SRC-4f21e6a2eabd29c3123db333`。
- 规范化机理：原表声明window区偏移计算错误，写入覆盖其他地址，导致MC2反向NaN。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | MC2窗口地址偏移 / mm_reduce_scatter_base | MODEL_DERIVED | SRC-4f21e6a2eabd29c3123db333 |
| 表现 | MC2反向精度出现nan | ORIGINAL_MODE_DECLARATION | SRC-df853a839412c16ed7bbca68 |
| 输入条件 | 使能 MC2 + 8 机训练 | MODEL_DERIVED | SRC-4d2d3905dc906f794f8ee371 |
| 执行条件 | 现网 CANN 8.0.0 + MC2 | MODEL_DERIVED | SRC-3b1a813aae0e52611eca591d |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-c3110906a4e159f67bdb0095 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-6216d11571fed0fb71e89e33 |

**A-D07 【现网问题】【版本代号已脱敏】MC2 反向精度出现 NaN**（DTS_SUMMARY；机理关系INTERNAL_SUMMARY_CONFLICT）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | CANN8.0.0+使能 MC2 首个 step 未跑完出现 NAN；dump 显示 npu_mm_reduce_scatter_base 输入一致输出差异大 |
| 触发 | 有条件必然重现 |
| 定位 | 员工已脱敏 |
| 根因 | 算子问题（窗口区偏移计算/地址踩踏，对应原表 M004） |
| 处理/修复 | 员工已脱敏 修改 |
| 验证 | 回归完成 |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-c68395171ac92cb8b66777ae |

相近周报索引：WB-036, WB-038, WB-055。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- Part4 D07根因括号引用原表窗口偏移，Part5/6却明确DTS未提该细节；不将回填原表的文字作为独立DTS证明。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M005 浮点数累加序不当

- 初始化：INITIALIZED；模式定义：PARTIALLY_SUPPORTED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：通信累加顺序不一致导致测试不通过，如不同测试脚本目前是只按照一种求和顺序来比较，而集合通信ReduceScatter实现不同rank天然就会有不同的加法顺序，出现结果不相等的情况。
- 来源：输入A，芯片使能（CANN）!F12（文档记录），`SRC-e9b0aa69133aff043359d260`。
- 规范化机理：不同rank的浮点求和顺序与单一顺序测试标杆不一致，fp16/bf16 sum结果出现差异。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 集合通信ReduceScatter(V) | MODEL_DERIVED | SRC-e9b0aa69133aff043359d260 |
| 表现 | reducescatterV在数据类型为float16、bfloat16 reducetype为sum时有精度问题 | ORIGINAL_MODE_DECLARATION | SRC-9f9ec354a5c6927a96403bf2 |
| 输入条件 | fp16/bf16 + reducetype=sum | MODEL_DERIVED | SRC-d63e941dae4f257ddeb074c2 |
| 执行条件 | HCCL/集合通信 ReduceScatterV | MODEL_DERIVED | SRC-522750d49611f880880f6594 |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-7b6d17c6504b1a11a9394246 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-32fab29fab91b550d4734ab1 |

**A-D06 【310P】【910B】ATB 支持 HCCL reducescatterV，fp16/bf16 reducetype=**（DTS_SUMMARY；机理关系SYMPTOM_ONLY_NOT_ROOT_CAUSE）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | fp16/bf16 sum 精度不过 |
| 触发 | 有条件必然重现 |
| 定位 | 员工已脱敏 |
| 根因 | 原文未给（原因分析空白） |
| 处理/修复 | 员工已脱敏 修改 |
| 验证 | 回归完成 |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-de0ea6fe2fb577529bf4b0e8 |

相近周报索引：WB-015, WB-022, WB-023, WB-033, WB-064。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D06只给精度不过，未给累加顺序根因；上游Part5的SUPPORTS过强。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M006 越界读写：shape错误

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：SetSize算子的infershape接口存在问题，output shape是-1，导致其后面的算子ReduceSum推导出的shape是个标量，进而导致分配内存异常；
- 来源：输入A，芯片使能（CANN）!F4（文档记录），`SRC-bf19d6ead4761d9d1da7aeac`。
- 规范化机理：原表声明infer-shape返回-1，后续算子推导为标量，导致内存分配异常。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | SetSize infer-shape到ReduceSum的形状链 | MODEL_DERIVED | SRC-bf19d6ead4761d9d1da7aeac |
| 表现 | 在进行虚机+容器精度测试下：TF_WideDeep的单P并发精度 测试时，出现训练失败的问题 | ORIGINAL_MODE_DECLARATION | SRC-69f16e755009690e74fc98d7 |
| 输入条件 | infershape 返回 -1 的算子链 | MODEL_DERIVED | SRC-05d0432898564836a64c5207 |
| 执行条件 | 虚机+容器精度测试 | MODEL_DERIVED | SRC-2d2e0c0487d78a08efc46af3 |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-2d9cd8bc823cea98a1430c25 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-b96fe0a5c4d16804005602cb |

**A-D02 【Atlas800型号9000】【kvm】TF_WideDeep 单P并发精度测试训练失败**（DTS_SUMMARY；机理关系SYMPTOM_ONLY_NOT_ROOT_CAUSE）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 虚机+容器精度测试训练失败 |
| 触发 | 有条件必然重现 |
| 定位 | 员工已脱敏 |
| 根因 | 与定位人确认目录存在问题，待进一步确认 |
| 处理/修复 | 员工已脱敏 修改（未给代码位置） |
| 验证 | 回归测试环节完成 |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-557bc31c724d24d03794cdea |

相近周报索引：暂无。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D02仅称目录问题、待确认，未证明SetSize/ReduceSum链。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M007 缺少同步

- 初始化：INITIALIZED；模式定义：PARTIALLY_SUPPORTED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：多核同时搬运可能会导致偶现精度问题
- 来源：输入A，芯片使能（CANN）!F7（文档记录），`SRC-3b48bc17e29827c233b382aa`。
- 规范化机理：原表推定多核同时搬运缺少必要同步，使相同调用偶现错误。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 多核数据搬运的同步依赖 | MODEL_DERIVED | SRC-3b48bc17e29827c233b382aa |
| 表现 | 算子输出偶现不一致 | ORIGINAL_MODE_DECLARATION | SRC-d515526d7c5b367135b60b27 |
| 输入条件 | 多核并发搬运（indices 与 grad_out 特定 shape） | MODEL_DERIVED | SRC-458b8cb64e27aa9e2adff814 |
| 执行条件 | AICORE 池化反向，tilingKey=2 | MODEL_DERIVED | SRC-7de62bf97ea4537730cd43fe |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-2bc3abec57f0d187d7c85c69 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-d06a57d5ce04f2b97281ba1f |

**A-D05 【算子开发自提】【CANN 9.0.RC1 B010】MaxPool3DGradWithArgmax 在指定 shape**（DTS_SUMMARY；机理关系SYMPTOM_ONLY_NOT_ROOT_CAUSE）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | self shape[1,17,15,5,5]、indices/grad_out[1,17,1,1,5] 时输出与竞品偶现不一致；同输入第一次对第二次错 |
| 触发 | 有条件概率重现 |
| 定位 | 员工已脱敏 |
| 根因 | 原文未给（定位到 tilingKey=2） |
| 处理/修复 | 员工已脱敏 修改 |
| 验证 | 回归完成 |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-2594e9a80eb1a41b371c83b6 |

相近周报索引：WB-009, WB-027, WB-050, WB-068, WB-070。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D05复现同输入第一次对第二次错，但未给同步根因。算子名不同不能单独证明DIFFERENT_EVENT。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M008 浮点数累加序不当

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：累加序实现不一致，如二分累加对比顺序累加，导致精度差异，如未设置export CLOSE_MATMUL_K_SHIFT=1时会有计算误差，具体可能是在router选择时容易出现较大偏差，导致评分下降
- 来源：输入A，芯片使能（CANN）!F16（文档记录），`SRC-c851534aabb5d657bb408d5f`。
- 规范化机理：浮点累加次序随实现/tiling变化，微小差异在router选路中放大。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | Matmul K错峰 / router数值敏感路径 | MODEL_DERIVED | SRC-c851534aabb5d657bb408d5f |
| 表现 | 模型在某些推理任务上下游评分下降 | ORIGINAL_MODE_DECLARATION | SRC-c2733a3a8bf4b2a49064e24e |
| 输入条件 | 特定 shape 使 matmul 走 K 错峰 tiling | MODEL_DERIVED | SRC-fd4e77ae9def4b0b1932b3b6 |
| 执行条件 | 推理；MoE router | MODEL_DERIVED | SRC-8989f21f44dbd4e2095e4171 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-ff9a698cf823205ce2085f52 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-21c0dcf2e9d93778b66fabeb |

**A-W04 【客户已脱敏】【在线推理】deepseek-V2-Lite开源模型下游任务评分有一个异常低问题**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | GPQA/MMLU 下游评分异常低；MoE 选路专家不同 |
| 触发 | 特定 shape 触发 matmul K 错峰 tiling |
| 定位 | 精度预检 + 分级可视化 + 真实数据 dump |
| 根因 | Matmul 受 shape 影响 tiling 策略导致计算误差；export CLOSE_MATMUL_K_SHIFT=1 关闭 K 错峰后与 GPU 对齐 |
| 处理/修复 | CLOSE_MATMUL_K_SHIFT=1 环境变量 |
| 验证 | 关闭 K 错峰后得分提升 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-f374d1cc8b4397f8250a20f1 |

子问题独立保留，不整页继承：

| 子问题 | 算子 | 摘要判断（上游） | 说明 |
| --- | --- | --- | --- |
| pow 与 topk 预检不通过；NPU TopK 只做有序排序 | TopK/pow | RELATED_ONLY | 排除：topk to-cpu 与单专家实验后评分无改善 |
| linear 每经过一次双千分之一指标下降约 10% | linear(MatMul) | RELATED_ONLY | 单算子符合精度标准 |
| MoE 选路专家不同（expert19 前 64 token 输入相同输出不同） | MoE router | RELATED_ONLY | shape 变化导致专家输入不同 |
| 关闭 CLOSE_MATMUL_K_SHIFT=1（K 错峰）后评分与 GPU 对齐 | matmul(K 错峰) | DIRECT_ROOT_CAUSE + DIRECT_FIX | GPQA 28.28→32.82，MMLU 53.63→58.58 |

相近周报索引：WB-001, WB-027, WB-030, WB-040, WB-054, WB-056, WB-060。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W04的TopK/pow及单算子合格linear只是排查分支，不能一并认作根因。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M009 精度溢出：数值格式精度不够导致精度溢出

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：baddbmm公式out=β input +α (batch1@batch2),计算时括号内为中间变量，超出fp16表示范围
- 来源：输入A，芯片使能（CANN）!F20（文档记录），`SRC-f0813efdc9daf08665ec6edb`。
- 规范化机理：中间乘积在低精度范围外，转换/保存为FP16时变为Inf，后续缩放无法恢复。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | baddbmm中间Matmul结果 | MODEL_DERIVED | SRC-f0813efdc9daf08665ec6edb |
| 表现 | 推理计算值为Inf | ORIGINAL_MODE_DECLARATION | SRC-dce2901c47557fdb60e3c2ba |
| 输入条件 | baddbmm 中间变量超 FP16 范围 | MODEL_DERIVED | SRC-8e7a13cde08e169a6d26823c |
| 执行条件 | aclnn 拆为 mm + mul 两步 | MODEL_DERIVED | SRC-e58df3aa31f5c7b63528781d |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-8ed0525ff2a93d91b12bd704 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-6c2afef7cee0040a530be422 |

**A-W05 【客户已脱敏】推理图像不一致，噪声重**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 推理图像不一致、噪声重；Torch.baddbmm 输出 -inf |
| 触发 | 中间变量 batch1@batch2≈-70000 超 FP16 |
| 定位 | dump 比对定位到 baddbmm |
| 根因 | mm 结果 cast 成 fp16 时溢出 |
| 处理/修复 | 调用前转 fp32、算完再转 fp16（单算子性能劣化约 160ms） |
| 验证 | 转 fp32 后推理正常 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-ecbada34d65dd3f29559588e |

相近周报索引：WB-002, WB-005, WB-065。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 不把中间结果Inf误归为输入原本含Inf；无本机历史修复Diff。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M010 融合算子反量化位置不当

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：图优化阶段因反量化（Dequantize）节点摆放位置错误，导致本应以纯INT8执行的融合算子退化为“反量化+高精度计算+再量化”路径，或使量化参数（scale/zero_point）传递断裂，最终引发精度异常
- 来源：输入A，芯片使能（CANN）!F28（文档记录），`SRC-cbfd780ebe0ca7cb408a5873`。
- 规范化机理：反量化节点位置或量化参数传递错误，改变融合图的计算路径。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 图优化中的Dequantize节点及量化参数传递 | MODEL_DERIVED | SRC-cbfd780ebe0ca7cb408a5873 |
| 表现 | 推理输出乱码 | ORIGINAL_MODE_DECLARATION | SRC-874a736e56cae9904b7466af |
| 输入条件 | UNKNOWN | UNKNOWN | SRC-de44e1bd2e9ec91309e314c7 |
| 执行条件 | 图融合优化 | MODEL_DERIVED | SRC-e7bec22236b48574f666a814 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-dc3c9fcb9339da48da44758a |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-da25e973421239b2a29b6dda |

没有历史Wiki/DTS摘要；模式依原声明正常初始化，证据保持MISSING_EVIDENCE/UNKNOWN。

相近周报索引：WB-034。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 原定义完整保留；没有图样例或历史链接，不等同于模式不存在。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M011 tiling切分策略分支错误

- 初始化：INITIALIZED；模式定义：PARTIALLY_SUPPORTED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：tiling逻辑判断或具体条件判断错误，导致走入错误分支
- 来源：输入A，芯片使能（CANN）!F14（文档记录），`SRC-379643568fa69a1dd317a863`。
- 规范化机理：Tiling条件判定错误，选择不适用的执行分支。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | Host Tiling分支判定 | MODEL_DERIVED | SRC-379643568fa69a1dd317a863 |
| 表现 | 网络loss不收敛 | ORIGINAL_MODE_DECLARATION | SRC-bd78449fdd641fd922dd86b7 |
| 输入条件 | 固定 shape + scatter_ 特定输入 | MODEL_DERIVED | SRC-b2a282eeaa5becb7e7d20c99 |
| 执行条件 | fastvideo 迁移；索引计算 | MODEL_DERIVED | SRC-9d7b9c53bae99cbff58d3457 |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-a081abbe49d93062ac48645c |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-569e1660ff24601895e07add |

**A-D09 【现网问题】【内部角色已脱敏】【严重】客户已脱敏/Atlas 800T A2，Scatter_ 算子在特定 shape 下报错**（DTS_SUMMARY；机理关系SYMPTOM_ONLY_NOT_ROOT_CAUSE）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | fastvideo 迁移中固定 shape 下 scatter_ 报错 |
| 触发 | 有条件必然重现 |
| 定位 | 员工已脱敏 |
| 根因 | 特定 shape 下 scatter_ 报错（单算子复现成功） |
| 处理/修复 | 员工已脱敏 修改 |
| 验证 | 回归完成 |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-93e6e96062de69ea27e04760 |

相近周报索引：WB-010, WB-047, WB-057。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D09只证明scatter_特定shape报错；不能据算子/描述差异判不同事件，也未证明具体分支。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M012 确定性计算未实现

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：RMSNorm小算子（Pow + ReduceMean + Add +Rsqrt）实现与RMSNorm算子不同；ReduceMean的确定性未能固定
- 来源：输入A，芯片使能（CANN）!F15（文档记录），`SRC-72c00c8db0479f6b30494648`。
- 规范化机理：归约过程未固定确定性，导致相同图推理重复调用结果随机。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | RMSNorm小算子组合中的ReduceMean | MODEL_DERIVED | SRC-72c00c8db0479f6b30494648 |
| 表现 | 有随机性，小算子无误差，可能导致无法复现故障 | ORIGINAL_MODE_DECLARATION | SRC-db6d88a30a2fc4f582cbf0f9 |
| 输入条件 | MOE 模型入图推理 | MODEL_DERIVED | SRC-21022432bd12c4315a0b6db6 |
| 执行条件 | 两次入图推理；小算子组合 | MODEL_DERIVED | SRC-729b0bd78c3c67956f53dc71 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-74ba9af9367aa82d51c7112b |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-6f4668134b35246c70d8ea25 |

**A-W06 内部项目MOE模型推理结果具有随机性**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 入图后 32 条两次结果随机，小算子无误差 |
| 触发 | 两次入图推理 |
| 定位 | GE dump 逐 token 比对 |
| 根因 | RMSNorm 小算子实现存在确定性问题（ReduceMean 确定性未固定） |
| 处理/修复 | 把小算子替换为 RMSNorm 后两次入图对齐 |
| 验证 | 替换后对齐 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-e00af2e845d8c8e84f87fb04 |

子问题独立保留，不整页继承：

| 子问题 | 算子 | 摘要判断（上游） | 说明 |
| --- | --- | --- | --- |
| 入图后两次结果随机 | RMSNorm 小算子(Pow+ReduceMean+Add+Rsqrt) | DIRECT_ROOT_CAUSE | 替换为 RMSNorm 后对齐 |
| GroupedMatMul/Mul 早前被怀疑 | GroupedMatMul | RELATED_ONLY | 输入本已不一致，非根因 |

**A-W07 内部项目MOE模型推理结果具有随机性(2)**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 入图后两次结果随机 |
| 触发 | 两次入图推理 |
| 定位 | GE dump 比对 |
| 根因 | RMSNorm 小算子实现存在精度问题，ReduceMean 确定性未固定；最新 CANN 已支持确定性计算 |
| 处理/修复 | 最新 CANN 包支持确定性计算 |
| 验证 | 替换 RMSNorm 后对齐 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-40e67f673f89d943113d49fc |

相近周报索引：WB-001, WB-004, WB-007, WB-050, WB-068。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W06/W07只作两个资料，不计两个故障；不与LCCL通信确定性自动合并。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M013 NPU适配引入额外参数

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：tik底层对coreNum特性，block_dim为scalar时支持不够导致的，需添加常量折叠配置。
- 来源：输入A，芯片使能（CANN）!F18（文档记录），`SRC-3d65d6157051edd48713c3b6`。
- 规范化机理：原表声明scalar形式block_dim的支持不足，需要常量折叠配置。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | tik coreNum / block_dim参数适配 | MODEL_DERIVED | SRC-3d65d6157051edd48713c3b6 |
| 表现 | tf框架bert离线推理精度下降21%左右 | ORIGINAL_MODE_DECLARATION | SRC-230515594df0e7f1c63b274f |
| 输入条件 | block_dim 为 scalar | MODEL_DERIVED | SRC-cb0b0437fcb58738e05f229a |
| 执行条件 | 310P3；ascend-toolkit 修改引入 | MODEL_DERIVED | SRC-fb8a927ff23796b321aec891 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-7db2075828a774ce24e40171 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-ccafe98a489e26bd899ff6ef |

**A-D01 【自动化】【继承特性】【310P3】【CANN 6.0.0.B070】 tf框架bert离线推理精度下降21%左右**（DTS_SUMMARY；机理关系SYMPTOM_ONLY_NOT_ROOT_CAUSE）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 装 b070 cann 后 bert 精度 0.93→0.73 |
| 触发 | 有条件必然重现 |
| 定位 | 员工已脱敏 |
| 根因 | 初步定位 ascend-toolkit 修改引入（具体原因定位中） |
| 处理/修复 | 开发 员工已脱敏 修改（未给代码位置） |
| 验证 | 回归测试环节完成 |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-24d4a8d793015335ff3745e6 |

相近周报索引：暂无。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D01是自动扫描的BERT精度退化，只初步定位toolkit修改，不能证明tik细节或客户事件身份。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M014 tensor下标超出数值范围

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：偏移量超出INT32数值范围
- 来源：输入A，芯片使能（CANN）!F19（文档记录），`SRC-b711249e77351636e8a5f8fe`。
- 规范化机理：地址/元素偏移超出INT32可表示范围，导致索引失真。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 地址偏移的窄整数算术 | MODEL_DERIVED | SRC-b711249e77351636e8a5f8fe |
| 表现 | 推理出现异常 | ORIGINAL_MODE_DECLARATION | SRC-901c010d90cce55e34820049 |
| 输入条件 | tensor 下标/偏移量超 INT32 | MODEL_DERIVED | SRC-6d7eb0ed77cdf8600f90d579 |
| 执行条件 | UNKNOWN | UNKNOWN | SRC-0f18b958a5b68247d5d8ad0c |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-f6ec118491c8a3c76f2fff51 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-7746fba4ba584981020a7a85 |

没有历史Wiki/DTS摘要；模式依原声明正常初始化，证据保持MISSING_EVIDENCE/UNKNOWN。

相近周报索引：WB-028。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 缺偏移公式、位宽提升位置及实际容量，不因大shape就确认溢出。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M015 越界读写：内存踩踏覆盖

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：FIA算子踩踏reducesum的内存，导致传入残差入口（add_3算子）的数据发生误差，导致残差之后的误差会不断放大
- 来源：输入A，芯片使能（CANN）!F23（文档记录），`SRC-002a5d15b67dc7d53782149b`。
- 规范化机理：FIA写入覆盖ReduceSum使用的内存，残差入口错误进一步放大。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | FIA工作区写入与ReduceSum/残差数据 | MODEL_DERIVED | SRC-002a5d15b67dc7d53782149b |
| 表现 | 输出乱码 | ORIGINAL_MODE_DECLARATION | SRC-11dc417b49a33a2e78fae255 |
| 输入条件 | UNKNOWN：上游该字段混入W08的matmul cast事件，不能用于FIA内存踩踏定义。 | UNKNOWN | SRC-c4e573653aa4f0f868398098 |
| 执行条件 | UNKNOWN：上游该字段混入W08的matmul cast事件，不能用于FIA内存踩踏定义。 | UNKNOWN | SRC-701cbfbc8f301fae7ecd5848 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-816eccba1e2f747200135acb |
| 排除边界 | UNKNOWN：上游该字段混入W08的matmul cast事件，不能用于FIA内存踩踏定义。 | UNKNOWN | SRC-2dbe52d57fd6540c1fca9275 |

**A-W08 【客户已脱敏】llama3.1-70B 310P吞字问题定位记录**（WIKI_SUMMARY；机理关系CONFLICTING_MECHANISM）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 输出吞字、冗余、错误信息；300I DUO 与 800I A2 logits 13 个 token 全不同 |
| 触发 | 300I 系列不支持 fp32，matmul 输入 fp32→fp16 cast |
| 定位 | logits+tensor dump，PositionalEmbeddingGather→@ 算子 |
| 根因 | 300I DUO 需把 fp32 cast 成 fp16 才能 matmul，导致 @ 算子精度误差（kl≈17万，余弦 97%） |
| 处理/修复 | 把 @ 换成 torch.outer 或 * ，吞字消失 |
| 验证 | 替换后吞字消失 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-66c9557e3aa7e0076b68b46e |

子问题独立保留，不整页继承：

| 子问题 | 算子 | 摘要判断（上游） | 说明 |
| --- | --- | --- | --- |
| 300I DUO 吞字/冗余/错误信息 | torch_npu @(外积)/matmul | DIRECT_ROOT_CAUSE | 300I 需 fp32→fp16 cast |
| 80 层 decoder 误差累加导致 logits 全不同 | PositionEmbeddingGather/@ | DIRECT_SYMPTOM | 换成 torch.outer/* 后消失 |

相近周报索引：WB-029, WB-036, WB-038, WB-055, WB-073。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W08解释的是300I matmul FP32→FP16 cast，未支持FIA踩踏；剔除该证据对本模式的根因支持，保留原引用。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M016 精度溢出：特定硬件数值格式导致精度溢出

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：调用的是BNInferenceD算子，该算子在310P fp16场景有概率发生精度溢出
- 来源：输入A，芯片使能（CANN）!F26（文档记录），`SRC-bbb7aba1bd94da37493ad718`。
- 规范化机理：倒数等中间运算超出FP16表示范围，造成归一化精度溢出。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 310P FP16 BNInferenceD | MODEL_DERIVED | SRC-bbb7aba1bd94da37493ad718 |
| 表现 | onnx转om出现精度下降 | ORIGINAL_MODE_DECLARATION | SRC-cbb588dde6ed8fe2cd7aca33 |
| 输入条件 | 310P fp16 + weight 极小 | MODEL_DERIVED | SRC-a26dcabdbac21fc4bfc3e4b7 |
| 执行条件 | onnx→om 转换 | MODEL_DERIVED | SRC-b8064f3698a2fc10ed837e56 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-71dd757b5e95e409885bea16 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-39a7a811485ae213e857277f |

**A-W09 客户已脱敏conformer模型om精度异常**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | onnx→om 精度下降 |
| 触发 | 310P fp16 + weight 极小 |
| 定位 | dump 比对发现 BatchNormalization_*_BNInferenceD 余弦骤降 |
| 根因 | BNInferenceD 在 310P fp16 下 1/weight 溢出 |
| 处理/修复 | 开关置 on 将 BNInferenceD 换 BNInfer（性能损失但内部精度更高） |
| 验证 | 开关后精度正常 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-39a036cad1daaed326347424 |

相近周报索引：暂无。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 只在摘要所述310P、极小weight条件下支持；精确阈值及实现仍未知。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M017 tiling切分策略不同分支处理精度不一致

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：PageAttention blockSize 不同时，会有不同的tiling选择，结果精度不能保持二进制一致
- 来源：输入A，芯片使能（CANN）!F30（文档记录），`SRC-f37548c4acf7cbb9dce8cb35`。
- 规范化机理：不同分块/算法更新路径产生不同舍入累加结果，不能保证跨配置二进制一致。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | PA/FA不同Tiling与blockSize分支 | MODEL_DERIVED | SRC-f37548c4acf7cbb9dce8cb35 |
| 表现 | 开启确定性计算，每次推理输出结果不一致 | ORIGINAL_MODE_DECLARATION | SRC-b05cab796604b99e25f3a484 |
| 输入条件 | batch/headnum/blockSize 触发不同 tiling 分支 | MODEL_DERIVED | SRC-24804b52b204b09fb02f0f89 |
| 执行条件 | 服务化推理；batchsize 变化 | MODEL_DERIVED | SRC-7bef18dae4e60ada18128e37 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-1f6e74a84ed0c99a837a4b50 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-2688036772a8bc7fd3ebae76 |

**A-W10 【客户已脱敏】确定性计算不一致问题定位**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 开启确定性计算每次输出不一致 |
| 触发 | 服务化调度使 batchsize 不同触发不同 tiling |
| 定位 | ait dump 逐层比对定位到 PA 算子 |
| 根因 | PA/FA 属 softmax 逐步更新算法，tiling 不同 + PA blockSize 不同导致结果不能二进制一致 |
| 处理/修复 | 符合算子精度标准（未改）；定位用途 |
| 验证 | 结果符合算子精度标准 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-25ccdbde63ed2b1f515cbd6d |

相近周报索引：WB-040, WB-056。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W10明确符合算子精度标准；不能当作已证实Kernel Bug或同实参随机竞争。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M018 浮点数累加序不当

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：attention算子输入shape不一样导致Tiling 策略并行粒度变化，输出微小差异带来精度误差
- 来源：输入A，芯片使能（CANN）!F32（文档记录），`SRC-fd6787c70348dc9d6bbc5525`。
- 规范化机理：原表将不同shape下的输出微差归因于Tiling并行粒度变化。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | Attention随shape改变的计算粒度 | MODEL_DERIVED | SRC-fd6787c70348dc9d6bbc5525 |
| 表现 | 全量4096输入 vs 91输入输出结果不一致 | ORIGINAL_MODE_DECLARATION | SRC-cd6a2f9ae495bc41dec4a37c |
| 输入条件 | 输入 shape 不同 | MODEL_DERIVED | SRC-6336e42582954b8c59f9d9d5 |
| 执行条件 | attention 推理/训练大算子差异 | MODEL_DERIVED | SRC-78937f00f66ab095fa43d089 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-1ec2c374d4a987183e499815 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-e7d8f669e4c83a73d6b650ef |

**A-W11 盘古72bmoev1适配推理问题**（WIKI_SUMMARY；机理关系PARTIAL_OR_UNRESOLVED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 全量 4096 与 91 输入第 92 位置 logits 不同 |
| 触发 | attention 输入 shape 不同 |
| 定位 | 仅现象与粗略结论 |
| 根因 | attention 内输入 shape 不同会有微小差异，推理/训练大算子差异带来精度误差 |
| 处理/修复 | 无（对方已找到原因，不再定位） |
| 验证 | 未闭环 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-06dc483814251b61958c69a6 |

相近周报索引：暂无。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W11自述不再定位，没有闭环，不能确认具体累加序。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M019 数学等价但计算结果不等价

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：FA反向计算时顺序不合适（数学等价）导致精度不足
- 来源：输入A，芯片使能（CANN）!F11（文档记录），`SRC-c676fafbbc8fc31a8e890df8`。
- 规范化机理：数学等价的求值顺序在有限精度下不等价，导致精度不足。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | FA反向计算的等价表达式求值顺序 | MODEL_DERIVED | SRC-c676fafbbc8fc31a8e890df8 |
| 表现 | 大模型训练崩溃 | ORIGINAL_MODE_DECLARATION | SRC-e8f3252c64224c511447a6af |
| 输入条件 | UNKNOWN | UNKNOWN | SRC-c44efc3c2feb8f35fe13554d |
| 执行条件 | UNKNOWN | UNKNOWN | SRC-f932aa55a246657b628b6aff |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-2c0ea70dad313757772333f0 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-125652fd262faa8d177792b1 |

没有历史Wiki/DTS摘要；模式依原声明正常初始化，证据保持MISSING_EVIDENCE/UNKNOWN。

相近周报索引：WB-065, WB-076。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 没有历史链接、公式与复现；不覆盖bool逻辑归约语义错误。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M020 空tensor处理不当

- 初始化：INITIALIZED；模式定义：PARTIALLY_SUPPORTED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：embedding前向输入为空导致反向NaN
- 来源：输入A，芯片使能（CANN）!F3（文档记录），`SRC-822d0018d96866ff063ad602`。
- 规范化机理：空输入的边界处理未满足后续梯度计算要求，导致NaN。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | Embedding等算子的空输入处理 | MODEL_DERIVED | SRC-822d0018d96866ff063ad602 |
| 表现 | 第一步gradnorm为NAN | ORIGINAL_MODE_DECLARATION | SRC-41d9db4d19479f2da0840e7c |
| 输入条件 | 空 tensor 输入 | MODEL_DERIVED | SRC-6ae765def827a1e279f3f1cc |
| 执行条件 | 训练反向 | MODEL_DERIVED | SRC-693973a15f62259dd4fcfb2e |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-07173b178d94fed8f79dbe7a |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-4c085cdf9a15fc8d1f182dbf |

**A-W12 客户已脱敏cann1230有NaN问题**（WIKI_SUMMARY；机理关系PARTIAL_OR_UNRESOLVED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 1230 出现 NaN，330 不出现 |
| 触发 | 输入有空值 |
| 定位 | 采集数据 |
| 根因 | 排查到输入有空值，梯度收集时总梯度变 NaN |
| 处理/修复 | 未记 |
| 验证 | 未记 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-d2e2a3ff6c45a7fea7f307a9 |

相近周报索引：WB-042, WB-044, WB-049。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W12只有输入空值、总梯度NaN，未给embedding具体写回机制；输出未初始化是待扩展详情。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M021 矩阵乘加融合后数据格式转换精度丢失

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：MatmulAtomicAddUbFusion打开矩阵乘法加法融合，特定shape下matmul算子 在线编译和二进制的输出会有精度差距
- 来源：输入A，芯片使能（CANN）!F31（文档记录），`SRC-32cf3df1acb14a40aae88e3e`。
- 规范化机理：融合及编译路径改变Cast和计算顺序，导致在线编译与二进制路径输出不一致。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | MatmulAtomicAddUbFusion / Cast融合路径 | MODEL_DERIVED | SRC-32cf3df1acb14a40aae88e3e |
| 表现 | 盘古7B 从910B迁移到310P存在精度误差 | ORIGINAL_MODE_DECLARATION | SRC-38044bfd193a6d750adbef79 |
| 输入条件 | input0[201,11008]×input1[11008,4096] | MODEL_DERIVED | SRC-aaa6778011415ccf0067d6fd |
| 执行条件 | 在线编译 vs 二进制编译 | MODEL_DERIVED | SRC-4d7f28ba36fff5728e6e02e8 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-d671dd7082496eadd2f17de2 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-43a1d29cd1b9a4dde7a0ffec |

**A-W13 盘古7B 310P 在线编译和二进制编译精度不一致**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 关闭在线编译后性能好转但存在精度误差 |
| 触发 | shape input0[201,11008]×input1[11008,4096] |
| 定位 | 单算子复现 + profiling |
| 根因 | 在线编译对数据做 Cast(fp16→fp32→fp16) 造成精度损失；matmul_atomic_add_ub_fusion.cc/matmul_cast_fusion_pass.cc 融合后 FP32 出 |
| 处理/修复 | 关闭 MatmulAtomicAddUbFusion 后一致 |
| 验证 | ULP=0.0004433<0.001 符合精度标准 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-6f7f0d1ca6b8134258e3f6f4 |

相近周报索引：WB-003。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 历史摘要同时写门禁拦截和ULP达标，应分别保留指标/判定口径；不自动推成不合格Bug。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M022 搬运逻辑错误：blocktable有错误

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：Block Table 目前的索引和但kvCacheOut 的batch 偏移不一致
- 来源：输入A，芯片使能（CANN）!F8（文档记录），`SRC-d556251025040180c6bcf998`。
- 规范化机理：BlockTable索引与KV输出batch偏移不一致，发生错误搬运。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | ATB KVSelect的BlockTable和KV cache batch偏移 | MODEL_DERIVED | SRC-d556251025040180c6bcf998 |
| 表现 | 某些特定shape用例下算子精度错误 | ORIGINAL_MODE_DECLARATION | SRC-783d9f0eeacff0a32723d6d2 |
| 输入条件 | batch=143 / [2896,128,59,128] | MODEL_DERIVED | SRC-6ba3efc30f71ee7f7871b732 |
| 执行条件 | ATB KVSelect | MODEL_DERIVED | SRC-58b2dd631a8be9b82b4b1d46 |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-ae005a77c5afb5b67f800972 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-03224790f225ec31e24655aa |

**A-D04 【版本代号已脱敏版本测试】【ATB】【910B】ATB KVSelect Op 支持 Block HashTopk，特定用例[**（DTS_SUMMARY；机理关系SYMPTOM_ONLY_NOT_ROOT_CAUSE）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | [2896,128,59,128] 精度不过 |
| 触发 | 有条件必然重现 |
| 定位 | 员工已脱敏 |
| 根因 | 原文未给（原因分析空白） |
| 处理/修复 | 员工已脱敏 修改 |
| 验证 | 回归完成 |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-b3c72aed678209855bb37af9 |

相近周报索引：WB-028。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D04原因分析空白，只证明特定shape精度问题，不能核实偏移根因。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M023 tiling切分策略的逻辑异常

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：tiling逻辑计算有误，如未适配多种芯片核数，例310P3 8个核，310P1 10个核，前者能正常执行但后者报错
- 来源：输入A，芯片使能（CANN）!F13（文档记录），`SRC-0aaa41fed7b0efac00c8358a`。
- 规范化机理：Tiling未正确适配不同芯片可用核数，导致特定平台执行错误。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 跨芯片核数的Tiling适配 | MODEL_DERIVED | SRC-0aaa41fed7b0efac00c8358a |
| 表现 | 算子执行报错 | ORIGINAL_MODE_DECLARATION | SRC-a87c04b9ee13c46e87b7452d |
| 输入条件 | 310P1/310P3 核数差异 | MODEL_DERIVED | SRC-167c65d2404073257326a182 |
| 执行条件 | 多芯片核数适配 | MODEL_DERIVED | SRC-a676e96e6005666334e12f03 |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-e1da855b88229343eaddd793 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-47172d317291b8b74a6178c6 |

**A-D10 无权限查看该问题单**（DTS_SUMMARY；机理关系UNKNOWN）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | UNKNOWN |
| 触发 | UNKNOWN |
| 定位 | UNKNOWN |
| 根因 | UNKNOWN |
| 处理/修复 | UNKNOWN |
| 验证 | UNKNOWN |
| 上游采集状态 | PARTIAL |
| 本轮来源 | SRC-b3f812c293e808a2b8a1dbb4 |

相近周报索引：暂无。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D10无权限；上游九条未确认清单漏列此项，不能因列表遗漏视为已确认。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M024 数据排布转换错误

- 初始化：INITIALIZED；模式定义：PARTIALLY_SUPPORTED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：数据在内存排布转换发生错误，如NZ排布转换实现方案存在问题。
- 来源：输入A，芯片使能（CANN）!F9（文档记录），`SRC-f781d0e3989ef1e15543920b`。
- 规范化机理：内存排布转换实现错误，改变数据对应关系。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | NZ等内存布局转换 | MODEL_DERIVED | SRC-f781d0e3989ef1e15543920b |
| 表现 | 导致上层算子某些情况下精度错误 | ORIGINAL_MODE_DECLARATION | SRC-7fd957366b3891d3e6f11313 |
| 输入条件 | NZ 排布转换路径 | MODEL_DERIVED | SRC-cfc1253e4643ff307fe78469 |
| 执行条件 | aclnnFlashAttentionScoreGrad BNSD | MODEL_DERIVED | SRC-1cd3f642de37ba016d97d379 |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-1d41dc9397b17c8fb911494b |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-22706f3507670e780ae3bcdd |

**A-D08 【客户已脱敏】【现网提单】aclnnFlashAttentionScoreGrad 在 q 句长>k/v 且每 batch q**（DTS_SUMMARY；机理关系SYMPTOM_ONLY_NOT_ROOT_CAUSE）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 1,16,S1=256,S2=32,128 BNSD case 精度异常（RC2 正常） |
| 触发 | 有条件必然重现 |
| 定位 | 员工已脱敏 |
| 根因 | aclnnFlashAttentionScoreGrad 算子精度问题（初步） |
| 处理/修复 | 员工已脱敏 修改 |
| 验证 | 回归完成(2026-01-09) |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-bd57775e68fdc088156e6bef |

相近周报索引：WB-034, WB-045, WB-071。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D08只定位FAG精度问题，未说明NZ转换；附件fa.zip缺失，不能确认转换根因。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M025 算子实现精度不一致：指数函数精度实现错误

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：Tensor.exponoential_算子实现精度不一致
- 来源：输入A，芯片使能（CANN）!F21（文档记录），`SRC-c96b0044562c8f9e8c0aa49e`。
- 规范化机理：采样实现/随机数生成质量差异影响推理输出和评分。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | Tensor.exponential_随机采样 | MODEL_DERIVED | SRC-c96b0044562c8f9e8c0aa49e |
| 表现 | 推理评分降低，从60降低至30 | ORIGINAL_MODE_DECLARATION | SRC-37a9253b224c4a318ec7cb74 |
| 输入条件 | vllm 采样 temperature=1 路径 | MODEL_DERIVED | SRC-7e834dec2867a8f2a7c107fd |
| 执行条件 | vllm 推理采样 | MODEL_DERIVED | SRC-807d19a7acb95ad2b12cb5fd |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-3b141b5ec9b730b1b4b50139 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-35bcc018562ba11d5ba41bd1 |

**A-W14 【客户已脱敏】 vllm精度问题定位**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | npu 推理评分低于 gpu；第 8 个 token logits 差很多 |
| 触发 | vllm 采样路径 |
| 定位 | 逐 token logits + L0 dump |
| 根因 | NPU exponential 随机数生成质量差导致评分差；GPU 侧曾误走 greedy |
| 处理/修复 | 升级 vllm-ascend 或 PTA（issue #31/commit 85c7675） |
| 验证 | CPU exponential 效果更好；升级可修复 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-6001e054992d7cdd88c8d09d |

相近周报索引：WB-021。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 原表exponoential_拼写原样保留；不把普通指数函数近似误差与随机采样实现混为一谈。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M026 越界读写：tiling切分策略的逻辑错误

- 初始化：INITIALIZED；模式定义：UNCONFIRMED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：测试脚本中输入的indices的tensor大小未对齐32b
- 来源：输入A，芯片使能（CANN）!F5（文档记录），`SRC-b961fd52f21dd94eb19cd215`。
- 规范化机理：原表声明测试脚本提供的indices大小未按32B对齐。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | indices的32B对齐和测试构造 | MODEL_DERIVED | SRC-b961fd52f21dd94eb19cd215 |
| 表现 | batch较大场景下泛化用例精度不够 | ORIGINAL_MODE_DECLARATION | SRC-91af31a56666559dac4df69a |
| 输入条件 | indices 未 32B 对齐 | MODEL_DERIVED | SRC-ddee5a38375abbc8ad4a3ede |
| 执行条件 | ATB KVSelect BlockHashTopk | MODEL_DERIVED | SRC-aa2f34dae76ede8cabc4e3c6 |
| 适用范围 | 训练 | ORIGINAL_MODE_DECLARATION | SRC-0e3177a518d767edbeca277c |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-be7c65ade6eb12768fc76e75 |

**A-D03 【版本代号已脱敏版本测试】【ATB】【310P】ATB KVSelect Op 支持 Block HashTopk，batch**（DTS_SUMMARY；机理关系SYMPTOM_ONLY_NOT_ROOT_CAUSE）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | batch=143 场景精度不够 |
| 触发 | 有条件必然重现 |
| 定位 | 员工已脱敏 |
| 根因 | 日志描述不清晰（原文） |
| 处理/修复 | 员工已脱敏 修改 |
| 验证 | 回归完成 |
| 上游采集状态 | COMPLETE |
| 本轮来源 | SRC-ca7c0a73fcbc1b92d3bb8883 |

相近周报索引：WB-036。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- D03没有32B细节，且未证明Kernel越界；可能是测试输入契约问题，不能把触发条件当成失效机理闭环。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M027 竞品实现不一致：特定私有数据排列格式

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：特定私有格式（NC1HWC0、NDHWC、NDC1HWC0、Z_3D）， 不支持as_strided的改变stride的view操作
- 来源：输入A，芯片使能（CANN）!F24（文档记录），`SRC-ad9e5647bba1a4975bf52e79`。
- 规范化机理：私有格式未适配改变stride的view，使inplace copy未正确作用于预期数据。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 私有格式Tensor的as_strided / inplace copy | MODEL_DERIVED | SRC-ad9e5647bba1a4975bf52e79 |
| 表现 | 图生视频，输出有竖线 | ORIGINAL_MODE_DECLARATION | SRC-77eb53b852d73ae68b09f807 |
| 输入条件 | 开启私有格式 + as_strided/copy_ | MODEL_DERIVED | SRC-98c18bce4ac428d81b01d901 |
| 执行条件 | CANN 8.0.RC3 + Atlas 200T A2 Box16 | MODEL_DERIVED | SRC-fa053350e43d485d4c48cfc3 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-0786723837f5d40b707a6746 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-a1028d429eda6d24beaba1c1 |

**A-W15 【客户已脱敏】cogvideo-5b-i2v打开私有格式推理生成的视频有竖线**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 开私有格式推理视频有竖线 |
| 触发 | 开启私有格式 + as_strided/copy_ |
| 定位 | 二分 + profiling(transdata) + 单算子脚本 |
| 根因 | NC1HWC0/NDHWC/NDC1HWC0/Z_3D 不支持 as_strided 改 stride 的 view，生成非私有格式 tensor 再 view，inplace copy_ 不生效 |
| 处理/修复 | 框架侧私有格式算子适配修复（已提单 pta，编号从略） |
| 验证 | 关闭私有格式竖线消失 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-79628565a7d979a78eca6ac9 |

子问题独立保留，不整页继承：

| 子问题 | 算子 | 摘要判断（上游） | 说明 |
| --- | --- | --- | --- |
| 开闭私有格式在 group_norm/groupnormsilu 算子有 0.002 差异 | group_norm | RELATED_ONLY | 算法不同，一般不导致结果差异 |
| as_strided 私有格式适配导致 inplace copy_ 不生效 | as_strided/aclnnInplaceCopy | DIRECT_ROOT_CAUSE + DIRECT_FIX | 已提单 pta |

相近周报索引：WB-025, WB-039, WB-046, WB-053, WB-071。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W15中group_norm约0.002差异是排查项，不并入该根因。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M028 确定性计算未实现

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：reducescatter算子，HCCL场景支持确定性计算，LCCL场景不支持确定性计算
- 来源：输入A，芯片使能（CANN）!F22（文档记录），`SRC-65917f4bff2a96fc2cdc8d9f`。
- 规范化机理：通信后端未实现确定性累加/执行，造成重复推理随机波动。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | LCCL ReduceScatter确定性路径 | MODEL_DERIVED | SRC-65917f4bff2a96fc2cdc8d9f |
| 表现 | deepseek A2单机精度,数据集aime,相邻版本正确率差异超10% | ORIGINAL_MODE_DECLARATION | SRC-1cd0783c92ef7f055d6e6edd |
| 输入条件 | 并行方式含 reducescatter（dp/tp/ep 组合） | MODEL_DERIVED | SRC-41b52eb8558baa22fa87cae4 |
| 执行条件 | MindIE 服务化；DP 上移特性 | MODEL_DERIVED | SRC-dfb9250c3a28b9eb16a6b7a7 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-cc314c684ab688f1c7ad6742 |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-fb8ad2977c499da90d0a788f |

**A-W16 【客户已脱敏】DeepSeek-R1 AIME数据集精度不及客户预期**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 回答 token 重复；正确率波动 66~76 低于论文 79 |
| 触发 | 含 reducescatter 的并行方式(dp/tp/ep) |
| 定位 | msit dump + 二分定位 reducescatter |
| 根因 | LCCL ReduceScatter 不支持确定性计算；另含 MLA 小偏差与 DP 上移特性 |
| 处理/修复 | 通信 backend 改 hccl 后多次请求回答一致；关闭 DP 上移避免重复 |
| 验证 | 改 hccl 后一致 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-d2de32f212e17c56b23b4811 |

子问题独立保留，不整页继承：

| 子问题 | 算子 | 摘要判断（上游） | 说明 |
| --- | --- | --- | --- |
| 部分问题回答 token 重复 | MLA | DIRECT_ROOT_CAUSE | 关闭 MLA 后纯模型重复消失；另有 DP 上移特性诱因 |
| 正确率波动 66~76（随机性） | ReduceScatter | DIRECT_ROOT_CAUSE + DIRECT_FIX | LCCL→HCCL 后多次请求一致 |

相近周报索引：WB-004, WB-015, WB-022, WB-023, WB-033, WB-064。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W16另含MLA重复和DP上移两个子问题，不可把它们都归为ReduceScatter。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M029 硬件导致算子不支持未拦截

- 初始化：INITIALIZED；模式定义：PARTIALLY_SUPPORTED；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：如300I系列机器均不支持处理fp32的dtype数据，matmul算子先将输入cast为FP16后进行计算；如310P不支持inf nan；如reshapeAndCacheNd在输入shape较大时走入了使用DataCopyPad分支，在310p上不支持该指令
- 来源：输入A，芯片使能（CANN）!F17（文档记录），`SRC-7e5dbd3d6eb75a1c3dfb20a6`。
- 规范化机理：原定义混列FP32不支持而降精度、Inf/NaN不支持及DataCopyPad指令不支持三种能力约束。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | 硬件/平台能力契约（原表三个子声明） | MODEL_DERIVED | SRC-7e5dbd3d6eb75a1c3dfb20a6 |
| 表现 | 模型输出吞字、产生冗余信息、错误信息；有精度问题 | ORIGINAL_MODE_DECLARATION | SRC-a838a68360e3608d8e6dd45b |
| 输入条件 | 300I DUO fp32 输入；310P inf/nan | MODEL_DERIVED | SRC-f02427b67a839525408e8767 |
| 执行条件 | tp8 推理；外积 @ 算子 | MODEL_DERIVED | SRC-49657917332091ac27c41313 |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-13ce7957f82e2f47ad2bb61b |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-f9d0b2718f23a1c87c32500c |

**A-W08 【客户已脱敏】llama3.1-70B 310P吞字问题定位记录**（WIKI_SUMMARY；机理关系PARTIAL_OR_UNRESOLVED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 输出吞字、冗余、错误信息；300I DUO 与 800I A2 logits 13 个 token 全不同 |
| 触发 | 300I 系列不支持 fp32，matmul 输入 fp32→fp16 cast |
| 定位 | logits+tensor dump，PositionalEmbeddingGather→@ 算子 |
| 根因 | 300I DUO 需把 fp32 cast 成 fp16 才能 matmul，导致 @ 算子精度误差（kl≈17万，余弦 97%） |
| 处理/修复 | 把 @ 换成 torch.outer 或 * ，吞字消失 |
| 验证 | 替换后吞字消失 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-66c9557e3aa7e0076b68b46e |

子问题独立保留，不整页继承：

| 子问题 | 算子 | 摘要判断（上游） | 说明 |
| --- | --- | --- | --- |
| 300I DUO 吞字/冗余/错误信息 | torch_npu @(外积)/matmul | DIRECT_ROOT_CAUSE | 300I 需 fp32→fp16 cast |
| 80 层 decoder 误差累加导致 logits 全不同 | PositionEmbeddingGather/@ | DIRECT_SYMPTOM | 换成 torch.outer/* 后消失 |

**A-W17 【客户已脱敏】语音zipformer小模型推理精度问题**（WIKI_SUMMARY；机理关系PARTIAL_OR_UNRESOLVED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | om 流式推理第 33 帧起精度问题 |
| 触发 | Data 数据过大导致 sub_6200 溢出；exp/where 输入含 inf |
| 定位 | debug compare + 子图 37 二分 |
| 根因 | 310P 不支持 inf/nan |
| 处理/修复 | 对所有 where 结构内 exp 做截断(0~65535)，关闭融合规则 |
| 验证 | 截断后达到客户预期，问题闭环 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-d8ef0645355dc9bab5c3fcc7 |

子问题独立保留，不整页继承：

| 子问题 | 算子 | 摘要判断（上游） | 说明 |
| --- | --- | --- | --- |
| sub_6200 因 Data 数据过大溢出（子图 37） | sub/mul_sub_sub 融合 | DIRECT_ROOT_CAUSE | 310P 不支持 inf/nan |
| exp/where 输入含 inf 导致后续 inf | exp/where | DIRECT_ROOT_CAUSE + DIRECT_FIX | 截断 exp 0~65535 后闭环 |

相近周报索引：WB-003, WB-017, WB-025, WB-032, WB-046, WB-063。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- W08支持cast、W17支持Inf/NaN摘要，DataCopyPad子声明未取证。分别保留，不自动拆分或把软件dtype缺支持等同于硬件不支持。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

### M030 输入数据类型强转低精丢失

- 初始化：INITIALIZED；模式定义：REFINED_WITH_EVIDENCE；原声明：SOURCE_DECLARED。
- 原故障原因（保持原文）：conv2d算子在进行计算之前，会把输入的tensor强制转换成FP16格式的，因为算子内部不支持FP32格式。所以计算出的结果和onnx就不对齐
- 来源：输入A，芯片使能（CANN）!F29（文档记录），`SRC-b13d0b3f0eb6cf984980655c`。
- 规范化机理：计算前将FP32输入降为FP16，损失信息并在后续argmax等非线性决策处放大。（MODEL_DERIVED，根因确认仍为UNKNOWN）。

| 字段 | 值 | 依据 | source_id |
| --- | --- | --- | --- |
| 故障对象 | Conv2d输入类型适配 | MODEL_DERIVED | SRC-b13d0b3f0eb6cf984980655c |
| 表现 | 推理精度不达标 | ORIGINAL_MODE_DECLARATION | SRC-451286bb211a353a08756ae5 |
| 输入条件 | conv2d 输入含 FP32 精度需求 | MODEL_DERIVED | SRC-5c1322ce6879d597b5ea59b8 |
| 执行条件 | encoder 小模型转 om | MODEL_DERIVED | SRC-0975b2d8e7bbb12c906de2db |
| 适用范围 | 推理 | ORIGINAL_MODE_DECLARATION | SRC-24df09046c74b1fbab4b13eb |
| 排除边界 | UNKNOWN | UNKNOWN | SRC-7927d1c3f5c06c8915f1a085 |

**A-W18 客户已脱敏encoder模型 2025/2/24出现新的精度问题**（WIKI_SUMMARY；机理关系SUPPORTS_AS_SUMMARIZED）

| 字段 | 文档摘要内容 |
| --- | --- |
| 现象 | 整网余弦≈0.97，argmaxd 精度减小 |
| 触发 | conv2d 输入含 FP32 |
| 定位 | 内部角色已脱敏 二分切图定位到 conv2d |
| 根因 | conv2d 计算前把输入强制转 FP16（内部不支持 FP32），与 onnx 不对齐且被 argmax 放大 |
| 处理/修复 | weight×10 + 输出除 10 改图；或用 C++ CPU 实现算子切片 |
| 验证 | 方案实现通过 |
| 上游采集状态 | COMPLETE（BODY，正文可取） |
| 本轮来源 | SRC-e37e3a17790c501009431f99 |

相近周报索引：WB-003, WB-012, WB-014, WB-072, WB-074。仅作待比对导航，不反填根因。

未决事项（均不阻塞数据 Init）：

- 不把其他算子输出类型/接口标记错误一律等同于输入cast。
- 冻结工作簿和28份原始快照未在本机取得；引用为Markdown转录/摘要，不是重新核验网页。

## 5. Agent 2 GitCode摘要与错误关联

27个PR的修改位置、前后逻辑、触发、机理及测试字段直接保存输入B摘要；上游“Diff证明”只保留为reported grade。本轮diff_independently_verified统一为false。

| PR | 原关联WB | 摘要标题 | 修改位置 |
| --- | --- | --- | --- |
| Ascend/MindIE-SD#548 | WB-038 | [Bugfix][ops]修复调频plugin异步执行资源管理问题 | csrc/plugin/frequency_regulator.cpp（+11/−132） |
| Ascend/op-plugin#4833 | WB-028 | fix: correct grad_probs dtype in npu_moe_token_unpermute_grad | op_plugin_functions.yaml、_meta_registrations.py、测试×2（+105/−3） |
| cann/ascend-transformer-boost#2094 | WB-001；WB-010；WB-047；WB-057 | fix 950 rmsnorm golden | tests/framework/python/CsvOpsTestTool/data_generation.py::RmsNormOperation（+17/−0） |
| cann/ascend-transformer-boost#2207 | WB-071 | fix name spelling error | example/op_demo/ring_mla/*、include/atb/infer_op_params.h、docs、set_env.sh（+31/−28） |
| cann/hccl#1034 | WB-023；WB-033；WB-064 | PCIE协议的时候不使用HcommBatchTransfer | 5 个 ins_temp_*_nhr.cc（all_gather/all_reduce/broadcast/reduce/reduce_scatter）（+7/−7） |
| cann/ops-math#4871 | WB-027 | 修复RadixTopK同步错误并预留AscendC API所需workspace | math/radix_top_k/op_host/*tiling.cpp、op_kernel/radix_top_k_{ub,utils,ws,ws_utils}.h（+97/−86） |
| cann/ops-math#6026 | WB-076；WB-077 | fix：reduce prod bool输出改用ReduceAll，对齐GPU逻辑和语义 | math/reduce_prod/op_api/aclnn_prod.cpp（+24/−6，两分支同改） |
| cann/ops-math#6030 | WB-076；WB-077 | fix：reduce prod bool输出改用ReduceAll，对齐GPU逻辑和语义 | math/reduce_prod/op_api/aclnn_prod.cpp（+24/−6，两分支同改） |
| cann/ops-nn#10622 | WB-002 | fix addmm and baddbmm beta = 0, precision error | matmul/batch_mat_mul_v3/.../aclnn_baddbmm.cpp、mat_mul_v3/.../aclnn_addmm.cpp（+7/−2） |
| cann/ops-nn#1562 | WB-074 | 修复算子bug&&修改aclnnIndexSelect中的文档 | index/gather_v2/op_api/aclnn_gather_v3.cpp 等（+7/−5） |
| cann/ops-nn#2285 | WB-056 | 拦截bias变化导致进入matmul v3kernel bin找不到的问题 | matmul/common/op_host/op_api/matmul_util.cpp（+1/−1） |
| cann/ops-nn#6170 | WB-072 | repeat_interleave支持边界shape | index/repeat_interleave/op_api/repeat_interleave.cpp（+14/−1） |
| cann/ops-nn#7443 | WB-032 | DEBUG: 删除foreach_copy A5 | foreach/foreach_copy/* 等 31 文件（+0/−4653） |
| cann/ops-transformer#12509 | WB-009 | 修复FIA_Kernel同步问题 | attention/incre_flash_attention/op_kernel/arch22/ifa_service_matmul_full_quant.h、incre_flash_attention_preload_mla.h（+754/−619，两分支同改） |
| cann/ops-transformer#12716 | WB-009 | 修复FIA_Kernel同步问题 | attention/incre_flash_attention/op_kernel/arch22/ifa_service_matmul_full_quant.h、incre_flash_attention_preload_mla.h（+754/−619，两分支同改） |
| cann/ops-transformer#2077 | WB-042；WB-044；WB-049 | 修复GroupedMatmul切K场景不支持K为0的问题 | gmm/grouped_matmul/op_host/op_api/aclnn_grouped_matmul.cpp、op_tiling/grouped_matmul_tiling.cpp（+56/−8） |
| cann/ops-transformer#3901 | WB-065 | bugfix unaligned scene oom | attention/flash_attention_score_grad/op_kernel/arch32/flash_attention_score_grad_s1s2_bn2.h（+4/−4） |
| cann/ops-transformer#4152 | WB-065 | FlashAttentionScoreGrad修复空tensor场景oom问题 | .../arch32/flash_attention_score_grad_template_tiling_key.h（+1/−1） |
| cann/ops-transformer#8365 | WB-029 | 修复NsaCompAtten内存检测问题 | attention/nsa_compress_attention/op_host/*tiling*、op_kernel/nsa_compress_attention_s1s2_bn2gs1_sab.h（+17/−2） |
| cann/ops-transformer#8367 | WB-029 | 修复NsaCompAtten内存检测问题 | attention/nsa_compress_attention/op_host/*tiling*、op_kernel/nsa_compress_attention_s1s2_bn2gs1_sab.h（+17/−2） |
| cann/ops-transformer#8443 | WB-070 | 修复SFAG同步问题与潜在风险 | attention/sparse_flash_attention_grad/*（+25/−16） |
| cann/ops-transformer#8445 | WB-070 | 修复SFAG同步问题与潜在风险 | attention/sparse_flash_attention_grad/*（+25/−16） |
| cann/ops-transformer#8448 | WB-025；WB-046 | Revert "A2A3 npu_fused_infer_attention_score 算子支持cache首轴非连续" | fused_infer_attention_score docs + op_api（+61/−217） |
| cann/ops-transformer#8458 | WB-025；WB-046 | Revert "A2A3 npu_fused_infer_attention_score 算子支持cache首轴非连续" | fused_infer_attention_score docs + op_api（+61/−217） |
| cann/ops-transformer#8752 | WB-036 | modify a2 a8w4 workspace k<n/2 | mc2/mega_moe/op_kernel/arch22/mega_moe_a2.h、..._bf16_w4a8.h（+33/−24） |
| cann/ops-transformer#8766 | WB-036 | 修复mega_moe在K2大于K的时候两个gmmA矩阵复用导致的问题 | mc2/mega_moe/op_host/op_tiling/arch22/mega_moe_tiling_arch22.cpp、op_kernel/arch22/mega_moe_kernel_a3.h（+23/−10） |
| cann/ops-transformer#9834 | WB-073 | LI UB duplicate fix | attention/lightning_indexer/op_kernel/arch35/lightning_indexer_service_vector.h（+9/−7） |

重点保留的边界：2094是测试golden；2077的GroupedMatmul不能证明LI/seg_reduce根因；8752/8766的MegaMoE不能证明dequant-swiglu或V scale；6026/6030的bool归约不能反填WB076/077；4833的反向dtype不能证明负索引问题；3901/4152的OOM不能证明softmax数值根因。来源引用保留，事件归属待核验。

M015/W08的FIA内存踩踏与300I matmul降精不同，W08不支持M015根因，相关触发条件保留UNKNOWN。M004/D07摘要内部冲突、M023/D10无权限，以及M007/M011仅有现象的情况继续保留。不同算子或缺少信息不能单独成立“不同事件”。

## 6. 未确认模式与后续Expansion

上游9条未确认模式全部INITIALIZED且定义状态仍为UNCONFIRMED：M004、M006、M010、M013、M014、M018、M019、M022、M026。其他证据不足/冲突也单独标记，并非其余21条均已证实。


上一轮77条Expansion建议文件保持原样；原3条历史草案和1项独立技术候选没有加入这30条。其旧资料范围可能超出本轮两份Markdown，不作为本轮Init的权威输入。Init验收不依赖Expansion全部闭环。

下一步可以先审阅已有模式定义和详情扩展，再定向核验争议资料；有明确来源的归类建议可继续推进，不必等待全部原文。任何正式新增、人工裁决或Baseline冻结仍需另行决定，本轮未执行。

## 7. 交付与复现

- [cann_30_init.json](cann_30_init.json)：30条已初始化记录及仅含输入A/B的来源注册表。
- [cann_30_original_schema.tsv](cann_30_original_schema.tsv)：原15列和来源定位，原值不改写。
- [cann_30_evidence.jsonl](cann_30_evidence.jsonl)：独立证据实体及SOURCE/EVENT/MODE关系。
- [cann_30_init_status.tsv](cann_30_init_status.tsv)：逐条Init、定义、证据、缺口状态。
- 本报告：CANN_30_INIT_REVIEW.md。

运行`cann_init.py`增量生成本轮5个文件；运行`test_cann_init.py`验证真实输入和复用产物。测试实际结果保存为`cann_30_init_validation.json`。这两个脚本不会调用旧build、原Workflow、网站、模型服务或SQLite。

结论：本轮完成30/30数据初始化；未声称30/30原文核验、根因确认或硬件验证。原输入、上一轮结果、state、历史及原42/V4均保留，未公开上传内部资料。
